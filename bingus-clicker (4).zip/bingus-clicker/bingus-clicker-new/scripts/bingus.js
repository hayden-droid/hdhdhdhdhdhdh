"use strict";

var setup = {};
var loopTimer = 0;

// TODO: Update the version numbering internally
var version = 19; // This is an ordinal used to trigger reloads.
var versionData = new VersionData(1,1,59,"alpha"); // this is not accurate

var saveTag = "bingus";
var saveTag2 = saveTag + "2"; // For old saves.
var saveSettingsTag = "bingusSettings";
var logRepeat = 1;

// Bingus size category minimums
var bingusSizes = [
	{ min_pop :      0, name: "Thorp"       , id : "thorp"      },
	{ min_pop :     20, name: "Hamlet"      , id : "hamlet"     },
	{ min_pop :     60, name: "Village"     , id : "village"    },
	{ min_pop :    200, name: "Small Town"  , id : "smallTown"  },
	{ min_pop :    666, name: "Hell"        , id : "hell"       },
	{ min_pop :   2000, name: "Large Town"  , id : "largeTown"  },
	{ min_pop :   5000, name: "Small City"  , id : "smallCity"  },
	{ min_pop :  10000, name: "Large City"  , id : "largeCity"  },
	{ min_pop :  20000, name:"Metro&shy;polis",id : "metropolis" },
	{ min_pop :  50000, name: "Small Nation", id : "smallNation"},
	{ min_pop : 100000, name: "Nation"      , id : "nation"     },
	{ min_pop : 200000, name: "Large Nation", id : "largeNation"},
	{ min_pop : 500000, name: "Empire"      , id : "empire"     }
];

var PATIENT_LIST = [
	"healer","cleric","farmer","soldier","cavalry","labourer",
	"woodcutter","miner","tanner","blacksmith","unemployed",
];

// Declare variables here so they can be referenced later.  
var curBingus = {
	bingusName: "Bingus",
	rulerName: "I DIED MAKING THIS!",

	zombie: { owned:0 },
	grave: { owned:0 },
	soultube: { owned:0 },
	enemySlain: { owned:0 },
	morale: { 
		mod: 		1.0,
		efficiency: 1.0
	},

	resourceClicks : 0, // For NeverClick
	attackCounter : 0, // How long since last attack?

	trader : {
		materialId: "",
		requested: 	0,
		timer: 		0, // How many seconds will the trader be around
		counter: 	0 // How long since last trader?
	},

	raid: {
		raiding: false, // Are we in a raid right now?
		victory: false, // Are we in a "raid succeeded" (Plunder-enabled) state right now?
		epop: 0,  // Population of enemy we're raiding.
		plunderLoot: {}, // Loot we get if we win.
		last: "",
		targetMax: bingusSizes[0].id // Largest target allowed
	},

	curWonder: {
		name: "",
		stage: 0, // 0 = Not started, 1 = Building, 2 = Built, awaiting selection, 3 = Finished.
		progress: 0, // Percentage completed.
		rushed: false
	},
	wonders:[],  // Array of {name: name, resourceId: resourceId} for all wonders.

	// Known deities.  The 0th element is the current game's deity.
	// If the name is "", no deity has been created (can also check for worship upgrade)
	// If the name is populated but the domain is not, the domain has not been selected.
	deities : [ { name:"", domain:"", maxDev:0 } ]  // array of { name, domain, maxDev }

	//xxx We're still accessing many of the properties put here by bingusData
	//elements without going through the bingusData accessors.  That should
	//change.
};

// These are not saved, but we need them up here for the asset data to init properly.
var population = {
	current:	0,
	living:		0,
	zombie:		0,
	limit:		0,
	healthy:	0,
	totalSick:	0,
	extra: 		0
};

// Caches the total number of each wonder, so that we don't have to recount repeatedly.
var wonderCount = {};

var bingusData = getBingusData(); // Giant array of data, defined in "data" js

// Build a variety of additional indices so that we can iterate over specific
// subsets of our bingus objects.
var resourceData	= []; // All resources
var buildingData	= []; // All buildings
var upgradeData 	= []; // All upgrades
var powerData 		= []; // All 'powers' //xxx This needs refinement.
var unitData 		= []; // All units
var achData 		= []; // All achievements
var sackable		= []; // All buildings that can be destroyed
var lootable		= []; // All resources that can be stolen
var killable		= []; // All units that can be destroyed
var homeBuildings	= []; // All buildings to be displayed in the home area
var homeUnits		= []; // All units to be displayed in the home area
var armyUnits		= []; // All units to be displayed in the army area
var basicResources	= []; // All basic (click-to-get) resources
var normalUpgrades	= []; // All upgrades to be listed in the normal upgrades area

// The resources that Wonders consume, and can give bonuses for.
var wonderResources = getWonderResources(bingusData); // defined in "data" js

// These are settings that should probably be tied to the browser.
var settings = {
	autosave: 			true,
	autosaveCounter: 	1,
	autosaveTime: 		60, //Currently autosave is every minute. Might change to 5 mins in future.
	customIncr: 		false,
	fontSize: 			1.0,
	delimiters: 		true,
	textShadow: 		false,
	notes: 				true,
	worksafe: 			false,
	useIcons: 			true
};


function setIndexArrays (bingusData) {
	bingusData.forEach(function(elem){ 
		if (!(elem instanceof BingusObj)) { 
			console.error("Unknown type:", elem);
			return; 
		}
		if (elem.type == "resource") { 
			resourceData.push(elem); 
			if (elem.vulnerable === true) { 
				lootable.push(elem); 
			}
			if (elem.subType == "basic") { 
				basicResources.push(elem); 
			} 
		} 
		if (elem.type == "building") { 
			buildingData.push(elem); 
			if (elem.vulnerable === true) { sackable.push(elem); }
			if (elem.subType == "normal" || elem.subType == "land") { homeBuildings.push(elem); } 
		}
		if (elem.subType == "prayer") { 
			powerData.push(elem); 
		} else if (elem.type == "upgrade") { 
			upgradeData.push(elem); 
			if (elem.subType == "upgrade") { 
				normalUpgrades.push(elem); 
			} 
		}
		if (elem.type == "unit") { 
			unitData.push(elem); 
			if (elem.vulnerable === true) { killable.push(elem); }
			if (elem.place == "home") { homeUnits.push(elem); }
			if (elem.place == "party") { armyUnits.push(elem); } 
		}
		if (elem.type == "achievement") { 
			achData.push(elem); 
		}
	});
}

function calculatePopulation () {

	population = {
		current:	0,
		living:		0,
		zombie:		curBingus.zombie.owned,
		limit:		0,
		limitIncludingUndead: 0,
		healthy:	0,
		totalSick:	0,
		extra: 		0
	};

	//Update population limit by multiplying out housing numbers
	population.limit = (
		bingusData.tent.owned 
		+ (bingusData.hut.owned * 3) 
		+ (bingusData.cottage.owned * 6) 
		+ (bingusData.house.owned * (10 + ((bingusData.tenements.owned) * 2) + ((bingusData.slums.owned) * 2))) 
		+ (bingusData.mansion.owned * 50)
	);
	population.limitIncludingUndead = population.limit + population.zombie;

	//Update sick workers
	unitData.forEach(function(unit) { 
		if (unit.isPopulation) { // has to be a player, non-special, non-mechanical
			population.current += unit.owned;
			
			if (unit.vulnerable) {
				// TODO Should this use 'killable'?
				population.healthy += unit.owned;
			}
			if (unit.ill) {
				population.totalSick += (unit.ill||0);
			} else {
				population.healthy += 1; // TODO: Not sure if this is calculated right
			}
		} else {
			population.extra += unit.owned;
		}
	});
	// Calculate housed/fed population (excludes zombies)
	population.living = Math.max(0, population.current - population.zombie);
	// Calculate healthy workers (should exclude sick, zombies and deployed units)
	// TODO: Doesn't subtracting the zombies here throw off the calculations in randomHealthyWorker()?
	population.healthy = Math.max(0, population.healthy - population.zombie);

	//Zombie soldiers dying can drive population.current negative if they are 
	// killed and zombies are the only thing left.
	// TODO: This seems like a hack that should be given a real fix.
	if (population.current < 0){
		if (curBingus.zombie.owned > 0){
			//This fixes that by removing zombies and setting to zero.
			curBingus.zombie.owned += population.current;
			population.current = 0;
		} else {
			console.warn("Warning: Negative current population detected.");
		}
	}	
}


function getBingusType () {
	var bingusType = bingusSizes.getBingusSize(population.living).name;
	if (population.living === 0 && population.limit >= 1000){
		bingusType = "Ghost Town";
	}
	if (population.zombie >= 1000 && population.zombie >= 2 * population.living){ //easter egg
		bingusType = "Necropolis";
	}
	return bingusType;
}



function getCurDeityDomain() { 
	return (curBingus.deities.length > 0) ? curBingus.deities[0].domain : undefined; 
}



// Tallies the number of each wonder from the wonders array.
function tallyWonderCount() {
	wonderCount = {};
	curBingus.wonders.forEach(function(elem) {
		var resourceId = elem.resourceId;
		if (!isValid(wonderCount[resourceId])) { wonderCount[resourceId] = 0; }
		++wonderCount[resourceId];
	});
}

// Return the production multiplier from wonders for a resource.
function getWonderBonus(resourceObj)
{
	if (!resourceObj) { return 1; }
	return (1 + (wonderCount[resourceObj.id]||0)/10);
}




// Reset the raid data.
function resetRaiding()
{
	curBingus.raid.raiding = false;
	curBingus.raid.victory = false;
	curBingus.raid.epop = 0;
	curBingus.raid.plunderLoot = {};
	curBingus.raid.last = "";

	// Also reset the enemy party units.
	unitData.filter(function(elem) { return ((elem.alignment == "enemy") && (elem.place == "party")); })
			.forEach(function(elem) { elem.reset(); });
}



function playerCombatMods() { 
	return (0.01 * ((bingusData.riddle.owned) + (bingusData.weaponry.owned) + (bingusData.shields.owned))); 
}

// Get an object's requirements in text form.
// Pass it a cost object and optional quantity
function getReqText(costObj, qty)
{
	if (!isValid(qty)) { qty = 1; }
	costObj = valOf(costObj,qty); // valOf evals it if it's a function
	if (!isValid(costObj)) { return ""; }

	var i, num;
	var text = "";
	for(i in costObj)
	{
		// If the cost is a function, eval it with qty as a param.  Otherwise
		// just multiply by qty.
		num = (typeof costObj[i] == "function") ? (costObj[i](qty)) : (costObj[i]*qty);
		if (!num) { continue; }
		if (text) { text += ", "; }
		text += prettify(Math.round(num)) + " " + bingusData[i].getQtyName(num);
	}

	return text;
}

// Returns when the player meets the given upgrade prereqs.
// Undefined prereqs are assumed to mean the item is unpurchasable
function meetsPrereqs(prereqObj)
{
	if (!isValid(prereqObj)) { return false; }
	var i;
	for(i in prereqObj)
	{
		//xxx HACK:  Ugly special checks for non-upgrade pre-reqs.
		// This should be simplified/eliminated once the resource
		// system is unified.
		if (i === "deity") { // Deity
			if (getCurDeityDomain() != prereqObj[i]) { return false; }
		} else if (i === "wonderStage") { //xxx Hack to check if we're currently building a wonder.
			if (curBingus.curWonder.stage !== prereqObj[i]) { return false; }
		} else if (isValid(bingusData[i]) && isValid(bingusData[i].owned)) { // Resource/Building/Upgrade
			if (bingusData[i].owned < prereqObj[i]) { return false; }
		}
	}

	return true;
}

// Returns how many of this item the player can afford.
// Looks only at the item's cost and the player's resources, and not
// at any other limits.
// Negative quantities are always fully permitted.
// An undefined cost structure is assumed to mean it cannot be purchased.
// A boolean quantity is converted to +1 (true) -1 (false)
//xxx Caps nonlinear purchases at +1, blocks nonlinear sales.
// costObj - The cost substructure of the object to purchase
function canAfford(costObj, qty)
{
	if (!isValid(costObj)) { return 0; }
	if (qty === undefined) { qty = Infinity; } // default to as many as we can
	if (qty === false) { qty = -1; } // Selling back a boolean item.
	var i;
	for(i in costObj)
	{
		if (costObj[i] === 0) { continue; }

		//xxx We don't handle nonlinear costs here yet.
		// Cap nonlinear purchases to one at a time.
		// Block nonlinear sales.
		if (typeof costObj[i] == "function") { qty = Math.max(0,Math.min(1,qty)); }

		qty = Math.min(qty,Math.floor(bingusData[i].owned/valOf(costObj[i])));
		if (qty === 0) { return qty; }
	}

	return qty;
}

// Tries to pay for the specified quantity of the given cost object.
// Pays for fewer if the whole amount cannot be paid.
// Return the quantity that could be afforded.
//xxx DOES NOT WORK for nonlinear building cost items!
function payFor(costObj, qty)
{
	if (qty === undefined) { qty = 1; } // default to 1
	if (qty === false) { qty = -1; } // Selling back a boolean item.
	costObj = valOf(costObj,qty); // valOf evals it if it's a function
	if (!isValid(costObj)) { return 0; }

	qty = Math.min(qty,canAfford(costObj));
	if (qty === 0) { return 0; }

	var i,num;
	for(i in costObj)
	{
		// If the cost is a function, eval it with qty as a param.  Otherwise
		// just multiply by qty.
		num = (typeof costObj[i] == "function") ? (costObj[i](qty)) : (costObj[i]*qty);
		if (!num) { continue; }
		bingusData[i].owned -= num;
	}

	return qty;
}

// Returns the number of the object that we could buy or sell, taking into
// account any applicable limits.
// purchaseObj - The object to purchase
// qty - Maximum number to buy/sell (use -Infinity for the max salable)
function canPurchase (purchaseObj, qty) {
	if (!purchaseObj) { return 0; }
	if (qty === undefined) { qty = Infinity; } // Default to as many as we can.
	if (qty === false) { qty = -1; } // Selling back a boolean item.

	// Can't buy if we don't meet the prereqs.
	if (!meetsPrereqs(purchaseObj.prereqs)) { 
		qty = Math.min(qty, 0); 
	}

	// Can't sell more than we have (if salable at all)
	qty = Math.max(qty, -(purchaseObj.salable ? purchaseObj.owned : 0));

	// If this is a relocation, can't shift more than our source pool.
	if (purchaseObj.source) { 
		qty = Math.min(qty, bingusData[purchaseObj.source].owned); 
	}

	// If this is a destination item, it's just a relocation of an existing
	// item, so we ignore purchase limits.  Otherwise we check them.
	if (purchaseObj.isDest && !purchaseObj.isDest()) { 
		qty = Math.min(qty, purchaseObj.limit - purchaseObj.total); 
	}

	// See if we can afford them; return fewer if we can't afford them all
	return Math.min(qty, canAfford(purchaseObj.require));
}

// Generate two HTML <span> texts to display an item's cost and effect note.
function getCostNote(bingusObj)
{
	// Only add a ":" if both items are present.
	var reqText = getReqText(bingusObj.require);
	var effectText = (isValid(bingusObj.effectText)) ? bingusObj.effectText : "";
	var separator = (reqText && effectText) ? ": " : "";

	return "<span id='"+bingusObj.id+"Cost' class='cost'>" + reqText + "</span>"
		 + "<span id='"+bingusObj.id+"Note' class='note'>" + separator + bingusObj.effectText + "</span>";
}

// Number format utility functions.
// - Allows testing the sign of strings that might be prefixed with '-' (like "-custom")
// - Output format uses the proper HTML entities for minus sign and infinity.
// Note that the sign of boolean false is treated as -1, since it indicates a
//   decrease in quantity (from 1 to 0).
function sgnnum(x) { return (x > 0) ? 1 : (x < 0) ? -1 : 0; }
function sgnstr(x) { return (x.length === 0) ? 0 : (x[0] == "-") ? -1 : 1; }
function sgnbool(x) { return (x ? 1 : -1); }
function absstr(x) { return (x.length === 0) ? "" : (x[0] == "-") ? x.slice(1) : x; }
function sgn(x) { return (typeof x == "number") ? sgnnum(x) 
					   : (typeof x == "string") ? sgnstr(x) 
					   : (typeof x == "boolean") ? sgnbool(x) : 0; }
function abs(x) { return (typeof x == "number") ? Math.abs(x) : (typeof x == "string") ? absstr(x) : x; }


// Pass this the item definition object.
// Or pass nothing, to create a blank row.
function getResourceRowText(purchaseObj)
{
	// Make sure to update this if the number of columns changes.
	if (!purchaseObj) { return "<tr class='purchaseRow'><td colspan='6'/>&nbsp;</tr>"; }

	var objId = purchaseObj.id;
	var objName = purchaseObj.getQtyName(0);
	var s = (
		'<tr id="'+ objId + 'Row" class="purchaseRow" data-target="'+ objId + '">'
		+ '<td>'
		+ '<img src="images/'+objId+'.png" class="icon icon-lg" alt="'+objName+'"/>'
		+ '<button data-action="increment">' + purchaseObj.verb + '</button>'
		+ '<label>' + objName + ':</label>'
		+ '</td>'
		+ '<td class="number mainNumber"><span data-action="display">.</span></td>'
		+ '<td class="number maxNumber">/ max: <span id="max'+objId+'">...</span></td>'
		+ '<td class="number net"><span data-action="displayNet">..</span>/s</td>'
		+ '</tr>'
	);
	return s;
}


function getPurchaseCellText(purchaseObj, qty, inTable) {
	if (inTable === undefined) { inTable = true; }
	// Internal utility functions.
	function sgnchr(x) { return (x > 0) ? "+" : (x < 0) ? "&minus;" : ""; }
	//xxx Hack: Special formatting for booleans, Infinity and 1k.
	function infchr(x) { return (x == Infinity) ? "&infin;" : (x == 1000) ? "1k" : x; }
	function fmtbool(x) {
		var neg = (sgn(x) < 0);
		return (neg ? "(" : "") + purchaseObj.getQtyName(0) + (neg ? ")" : "");
	}
	function fmtqty(x) { return (typeof x == "boolean") ? fmtbool(x) : sgnchr(sgn(x))+infchr(abs(x)); }
	function allowPurchase() {
		if (!qty) { return false; } // No-op

		// Can't buy/sell items not controlled by player
		if (purchaseObj.alignment && (purchaseObj.alignment != "player")) { return false; }

		// Quantities > 1 are meaningless for boolean items.
		if ((typeof purchaseObj.initOwned == "boolean")&&(abs(qty) > 1)) { return false; }

		// Don't buy/sell unbuyable/unsalable items.
		if ((sgn(qty) > 0) && (purchaseObj.require === undefined)) { return false; }
		if ((sgn(qty) < 0) && (!purchaseObj.salable)) { return false; }

		//xxx Right now, variable-cost items can't be sold, and are bought one-at-a-time.
		if ((qty != 1) && purchaseObj.hasVariableCost()) { return false; }

		return true;
	}

	var tagName = inTable ? "td" : "span";
	var className = (abs(qty) == "custom") ? "buy" : purchaseObj.type;  // 'custom' buttons all use the same class.

	var s = "<"+tagName+" class='"+className+abs(qty)+"' data-quantity='"+qty+"' >";
	if (allowPurchase()) 
	{ 
		s +="<button class='x"+abs(qty)+"' data-action='purchase'"+" disabled='disabled'>"+fmtqty(qty)+"</button>"; 
	}
	s += "</"+tagName+">";
	return s;
}

// Pass this the item definition object.
// Or pass nothing, to create a blank row.
function getPurchaseRowText (purchaseObj) {
	// Make sure to update this if the number of columns changes.
	if (!purchaseObj) { return "<tr class='purchaseRow'><td colspan='13'/>&nbsp;</tr>"; }

	var objId = purchaseObj.id;
	var s = "<tr id='"+objId+"Row' class='purchaseRow' data-target='"+purchaseObj.id+"'>";
 
	[-Infinity, "-custom", -100, -10, -1]
	.forEach(function(elem) { s += getPurchaseCellText(purchaseObj, elem); });

	var enemyFlag = (purchaseObj.alignment == "enemy") ? " enemy" : "";
	s += "<td class='itemname"+enemyFlag+"'>"+purchaseObj.getQtyName(0)+": </td>";

	var action = (isValid(population[objId])) ? "display_pop" : "display"; //xxx Hack
	s += "<td class='number'><span data-action='"+action+"'>0</span></td>";

	// Don't allow Infinite (max) purchase on things we can't sell back.
	[1, 10, 100, "custom", ((purchaseObj.salable) ? Infinity : 1000)]
	.forEach(function(elem) { s += getPurchaseCellText(purchaseObj, elem); });

	s += "<td>" + getCostNote(purchaseObj) + "</td>";
	s += "</tr>";

	return s;
}

// For efficiency, we set up a single bulk listener for all of the buttons, rather
// than putting a separate listener on each button.
function onBulkEvent(e) {
	switch (dataset(e.target,"action")) 
	{
		case "increment": return onIncrement(e.target);
		case "purchase" : return onPurchase(e.target);
		case "raid"     : return onInvade(e.target);
	}
	return false;
}

function addUITable(bingusObjs, groupElemName)
{
	var s="";
	bingusObjs.forEach(function(elem) { 
		s += elem.type == "resource" ? getResourceRowText(elem) 
				: elem.type == "upgrade"  ? getUpgradeRowText(elem)
					: getPurchaseRowText(elem); 
	});
	var groupElem = document.getElementById(groupElemName);
	groupElem.innerHTML += s;
	groupElem.onmousedown = onBulkEvent;
	return groupElem;
}


// We have a separate row generation function for upgrades, because their
// layout is differs greatly from buildings/units:
//  - Upgrades are boolean, so they don't need multi-purchase buttons.
//  - Upgrades don't need quantity labels, and put the name in the button.
//  - Upgrades are sometimes generated in a table with <tr>, but sometimes
//    outside of one with <span>.
function getUpgradeRowText(upgradeObj, inTable)
{
	if (inTable === undefined) { inTable = true; }
	var cellTagName = inTable ? "td" : "span";
	var rowTagName = inTable ? "tr" : "span";
	// Make sure to update this if the number of columns changes.
	if (!upgradeObj) { return inTable ? "<"+rowTagName+" class='purchaseRow'><td colspan='2'/>&nbsp;</"+rowTagName+">" : ""; }

	var s=  "<"+rowTagName+" id='"+upgradeObj.id+"Row' class='purchaseRow'";
	s +=    " data-target='"+upgradeObj.id+"'>";
	s +=    getPurchaseCellText(upgradeObj, true, inTable);
	s +=    "<"+cellTagName+">" + getCostNote(upgradeObj) + "</"+cellTagName+">";
	if (!inTable) { s += "<br />"; }
	s +=    "</"+rowTagName+">";
	return s;
}


function getPantheonUpgradeRowText(upgradeObj)
{
	if (!upgradeObj) { return ""; }

	var s = "<tr id='"+upgradeObj.id+"Row' class='purchaseRow'>";
	// Don't include devotion if it isn't valid.
	//xxx Should write a chained dereference eval
	s += "<td class='devcost'>";
	s +=     ((isValid(upgradeObj.prereqs) && isValid(upgradeObj.prereqs.devotion)) 
			? (upgradeObj.prereqs.devotion +"d&nbsp;") : "") +"</td>";
	//xxx The 'fooRow' id is added to make altars work, but should be redesigned.
	s += "<td class='"+upgradeObj.type+"true'><button id='"+upgradeObj.id+"' class='xtrue'";
	s += " data-action='purchase' data-quantity='true' data-target="+upgradeObj.id;
	s += " disabled='disabled' onmousedown=\"";
	// The event handler can take three forms, depending on whether this is
	// an altar, a prayer, or a pantheon upgrade.
	s += ((upgradeObj.subType == "prayer") ? (upgradeObj.id+"()")
										   : ("onPurchase(this)"));
	s += "\">" + upgradeObj.getQtyName() + "</button>";
	s += (isValid(upgradeObj.extraText) ? upgradeObj.extraText : "")+"</td>";
	s += "<td>" + getCostNote(upgradeObj) + "</td>";
	s += "</tr>";

	return s;
}

// Returns the new element
function setPantheonUpgradeRowText(upgradeObj)
{
	if (!upgradeObj) { return null; }
	var elem = document.getElementById(upgradeObj.id+"Row");
	if (!elem) { return null; }

	elem.outerHTML = getPantheonUpgradeRowText(upgradeObj); // Replaces elem
	return document.getElementById(upgradeObj.id+"Row"); // Return replaced element
}

// Dynamically create the upgrade purchase buttons.
function addUpgradeRows()
{
	ui.find("#upgradesPane").innerHTML += 
	   "<h3>Purchased Upgrades</h3>" + "<div id='purchasedUpgrades'></div>";

	// Fill in any pre-existing stubs.
	upgradeData.forEach( function(elem){ 
		if (elem.subType == "upgrade") { return; } // Did these above.
		if (elem.subType == "pantheon") { setPantheonUpgradeRowText(elem); }
		else { // One of the 'atypical' upgrades not displayed in the main upgrade list.
			var stubElem = document.getElementById(elem.id+"Row");
			if (!stubElem) { console.log("Missing UI element for "+elem.id); return; }
			stubElem.outerHTML = getUpgradeRowText(elem, false); // Replaces stubElem
			stubElem = document.getElementById(elem.id+"Row"); // Get stubElem again.
			stubElem.onmousedown=onBulkEvent;
		}
	});

	// Altars
	buildingData.forEach(function(elem) { if (elem.subType == "altar") { setPantheonUpgradeRowText(elem); } });

	// Deity granted powers
	powerData.forEach(function(elem) { if (elem.subType == "prayer") { setPantheonUpgradeRowText(elem); } });

	// Dynamically create two lists for purchased upgrades.
	// One for regular upgrades, one for pantheon upgrades.
	var text="", standardUpgStr="", pantheonUpgStr="";

	upgradeData.forEach( function(upgradeObj){ 
		text = "<span id='P"+upgradeObj.id +"' class='Pupgrade'>"
			+"<strong>"+upgradeObj.getQtyName()+"</strong>"
			+" &ndash; "+upgradeObj.effectText+"<br/></span>";
		if (upgradeObj.subType == "pantheon") { pantheonUpgStr += text; }
		else { standardUpgStr += text; }
	});

	ui.find("#purchasedUpgrades").innerHTML += standardUpgStr;
	ui.find("#purchasedPantheon").innerHTML = pantheonUpgStr;
}

function getLandTotals () {
	//Update land values
	var ret = { lands: 0, buildings: 0, free: 0 };
	buildingData.forEach(function(elem) { 
		if (elem.subType == "land") { ret.free     += elem.owned; }
		else                        { ret.buildings += elem.owned; }
	});
	ret.lands = ret.free + ret.buildings;
	return ret;
}

function typeToId(deityType) {
	if (deityType == "Battle")         { return "battle"; }
	if (deityType == "Bingus")           { return "bingus"; }
	if (deityType == "Blood")           { return "battle"; }
	if (deityType == "the Fields")     { return "fields"; }
	if (deityType == "the Underworld") { return "underworld"; }
	return deityType;
}
function idToType(domainId) {
	if (domainId == "battle")          { return "Battle"; }
	if (domainId == "bingus")            { return "Bingus"; }
	if (domainId == "blood")            { return "Blood"; }
	if (domainId == "fields")          { return "the Fields"; }
	if (domainId == "underworld")      { return "the Underworld"; }
	return domainId;
}



function getDeityRowText(deityId, deityObj)
{
	if (!deityObj) { deityObj = { name:"No deity", domain:"", maxDev:0 }; }

	return "<tr id='"+deityId+"'>"
	+ "<td><strong><span id='"+deityId+"Name'>"+deityObj.name+"</span></strong>"
	+ "<span id="+deityId+"Domain' class='deityDomain'>"+"</td><td>"+idToType(deityObj.domain)+"</span></td>"
	+ "<td><span id='" + deityId + "Devotion'>"+deityObj.maxDev+"</span></td></tr>";
}

function makeDeitiesTables()
{
	// Display the active deity
	var deityId = "deityA";
	ui.find("#activeDeity").innerHTML = '<tr id="' + deityId + '">'
	+ '<td><strong><span id="' + deityId + 'Name">'+'</span></strong>'
	+ '<span id="' + deityId + 'Domain" class="deityDomain">' + '</span></td>'
	+ '<td>Devotion: <span id="' + deityId + 'Devotion">'+'</span></td></tr>';

	// Display the table of prior deities.
	//xxx Change this to <th>, need to realign left.
	var s = "<tr><td><b>Name</b></td><td><b>Domain</b></td><td><b>Max Devotion</b></td></tr>";
	curBingus.deities.forEach(function(elem, i) {
		if ((i===0)&&(!elem.name)) { return; } // Don't display current deity-in-waiting.
		s += getDeityRowText("deity"+i,elem);
	});
	ui.find("#oldDeities").innerHTML = s;

	updateDeity();
}

function testAchievements(){
	achData.forEach(function(achObj) { 
		if (bingusData[achObj.id].owned) { return true; }
		if (isValid(achObj.test) && !achObj.test()) { return false; }
		bingusData[achObj.id].owned = true;
		gameLog("Achievement Unlocked: "+achObj.getQtyName());
		return true;
	});

	updateAchievements();
}

function setDefaultSettings(){
	// Here, we ensure that UI is properly configured for our settings.
	// Calling these with no parameter makes them update the UI for the current values.
	setAutosave();
	setCustomQuantities();
	textSize(0);
	setDelimiters();
	setShadow();
	setNotes();
	setWorksafe();
	setIcons();
}

// Game functions

//This function is called every time a player clicks on a primary resource button
function increment (objId) {
	var purchaseObj = bingusData[objId];
	var numArmy = 0;

	if (!purchaseObj) { console.log("Unknown purchase: "+objId); return; }

	unitData.forEach(function(elem) { 
		if ((elem.alignment == "player")&&(elem.species=="human")
										&&(elem.combatType)&&(elem.place == "home")) { 
			numArmy += elem.owned; 
		} 
	}); // Nationalism adds military units.

	purchaseObj.owned += purchaseObj.increment 
	  + (purchaseObj.increment * 9 * (bingusData.bingusservice.owned)) 
	  + (purchaseObj.increment * 40 * (bingusData.feudalism.owned)) 
	  + ((bingusData.serfs.owned) * Math.floor(Math.log(bingusData.unemployed.owned * 10 + 1))) 
	  + ((bingusData.nationalism.owned) * Math.floor(Math.log(numArmy * 10 + 1)));

	//Handles random collection of special resources.
	var specialChance = purchaseObj.specialChance;
	if (specialChance && purchaseObj.specialMaterial && bingusData[purchaseObj.specialMaterial]) {
		if ((purchaseObj === bingusData.food) && (bingusData.flensing.owned))    { specialChance += 0.1; }
		if ((purchaseObj === bingusData.death) && (bingusData.flensing.owned))    { specialChance += 0.1; }
		if ((purchaseObj === bingusData.stone) && (bingusData.macerating.owned)) { specialChance += 0.1; }
		if (Math.random() < specialChance){
			var specialMaterial = bingusData[purchaseObj.specialMaterial];
			var specialQty =  purchaseObj.increment * (1 + (9 * (bingusData.guilds.owned)));
			specialMaterial.owned += specialQty;
			gameLog("Found " + specialMaterial.getQtyName(specialQty) + " while " + purchaseObj.activity); // I18N
		}
	}
	//Checks to see that resources are not exceeding their limits
	if (purchaseObj.owned > purchaseObj.limit) { purchaseObj.owned = purchaseObj.limit; }

	ui.find("#clicks").innerHTML = prettify(Math.round(++curBingus.resourceClicks));
	updateResourceTotals(); //Update the page with totals
}

function onIncrement(control) { 
	// We need a valid target to complete this action.
	var targetId = dataset(control,"target");
	if (targetId === null) { return false; }

	return evilincrement(targetId);
}

// Buys or sells a unit, building, or upgrade.
// Pass a positive number to buy, a negative number to sell.
// If it can't add/remove as many as requested, does as many as it can.
// Pass Infinity/-Infinity as the num to get the max possible.
// Pass "custom" or "-custom" to use the custom increment.
// Returns the actual number bought or sold (negative if fired).
function doPurchase(objId,num){
	var purchaseObj = bingusData[objId];
	if (!purchaseObj) { console.log("Unknown purchase: "+objId); return 0; }
	if (num === undefined) { num = 1; }
	if (abs(num) ==  "custom") { num =  sgn(num) * getCustomNumber(purchaseObj); }

	num = canPurchase(purchaseObj,num);  // How many can we actually get?

	// Pay for them
	num = payFor(purchaseObj.require,num);
	if (abs(num) < 1) { 
		gameLog("Could not build, insufficient resources."); // I18N
		return 0;
	}

	//Then increment the total number of that building
	// Do the actual purchase; coerce to the proper type if needed
	purchaseObj.owned = matchType(purchaseObj.owned + num,purchaseObj.initOwned);
	if (purchaseObj.source) { bingusData[purchaseObj.source].owned -= num; }

	// Post-purchase triggers
	if (isValid(purchaseObj.onGain)) { purchaseObj.onGain(num); } // Take effect

	//Increase devotion if the purchase provides it.
	if (isValid(purchaseObj.devotion)) { 
		bingusData.devotion.owned += purchaseObj.devotion * num; 
		// If we've exceeded this deity's prior max, raise it too.
		if (curBingus.deities[0].maxDev < bingusData.devotion.owned) {
			curBingus.deities[0].maxDev = bingusData.devotion.owned;
			makeDeitiesTables();
		}
	}

	// If building, then you use up free land
	if (purchaseObj.type == "building") {
		bingusData.freeLand.owned -= num;
		// check for overcrowding
		if (bingusData.freeLand.owned < 0) {
			gameLog("You are suffering from overcrowding.");  // I18N
			adjustMorale(Math.max(num,-bingusData.freeLand.owned) * -0.0025 * (bingusData.codeoflaws.owned ? 0.5 : 1.0));
		}
	}

	updateRequirements(purchaseObj); //Increases buildings' costs
	updateResourceTotals(); //Update page with lower resource values and higher building total
	updatePopulation(); //Updates the army display
	updateResourceRows(); //Update resource display
	updateBuildingButtons(); //Update the buttons themselves
	updateJobButtons(); //Update page with individual worker numbers, since limits might have changed.
	updatePartyButtons(); 
	updateUpgrades(); //Update which upgrades are available to the player
	updateDevotion(); //might be necessary if building was an altar
	updateTargets(); // might enable/disable raiding

	return num;
}

function onPurchase(control) { 
	// We need a valid target and a quantity to complete this action.
	var targetId = dataset(control,"target");
	if (targetId === null) { return false; }

	var qty = dataset(control,"quantity");
	if (qty === null) { return false; }

	return doPurchase(targetId, qty);
}


function getCustomNumber(bingusObj){
	if (!bingusObj||!bingusObj.customQtyId) { return undefined; }
	var elem = document.getElementById(bingusObj.customQtyId);
	if (!elem) { return undefined; }

	var num = Number(elem.value);

	// Check the above operations haven't returned NaN
	// Also don't allow negative increments.
	if (isNaN(num) || num < 0){
		elem.style.background = "#f99"; //notify user that the input failed
		return 0;
	} 

	num = Math.floor(num); // Round down

	elem.value = num; //reset fractional numbers, check nothing odd happened
	elem.style.background = "#fff";

	return num;
}


//Calculates and returns the cost of adding a certain number of workers at the present population
//xxx Make this work for negative numbers
function calcWorkerCost(num, curPop){
	if (curPop === undefined) { 
		curPop = population.living;
	}
	return (20*num) + calcArithSum(0.01, curPop, curPop + num);
}
function calcZombieCost(num){ 
	return calcWorkerCost(num, population.zombie)/5; 
}



// Create a bingus
function spawnBingus() {
	++bingusData.bingus.owned;
	gameLog("Found a bingus!");
}

// Creates or destroys workers
function spawn(num){
	var newJobId = "unemployed";
	var bums = bingusData.unemployed;
	if (num == "custom" ) { num =  getCustomNumber(bums); }
	if (num == "-custom") { num = -getCustomNumber(bums); }

	// Find the most workers we can spawn
	num = Math.max(num, -bums.owned);  // Cap firing by # in that job.
	num = Math.min(num,logSearchFn(calcWorkerCost,bingusData.food.owned));

	// Apply population limit, and only allow whole workers.
	num = Math.min(num, (population.limit - population.living));

	// Update numbers and resource levels
	bingusData.food.owned -= calcWorkerCost(num);

	// New workers enter as a job that has been selected, but we only destroy idle ones.
	newJobId = ui.find("#newSpawnJobSelection").value;
	if (num >= 0 && typeof bingusData[newJobId] === "object") {
		bingusData[newJobId].owned += num;
	} else { 
		bums.owned += num; 
	}
	calculatePopulation(); //Run through the population->job update cycle

	//This is intentionally independent of the number of workers spawned
	if (Math.random() * 100 < 1 + (bingusData.lure.owned)) { spawnBingus(); }

	updateResourceTotals(); //update with new resource number
	updatePopulation();
	
	return num;
}

// Picks the next worker to starve.  Kills the sick first, then the healthy.
// Deployed military starve last.
// Return the job ID of the selected target.
function pickStarveTarget() {
	var modNum,jobNum;
	var modList=["ill","owned"]; // The sick starve first
	//xxx Remove this hard-coded list.
	var jobList=["unemployed","blacksmith","tanner","miner","woodcutter",
		"cleric","cavalry","soldier","healer","labourer","farmer"];

	for (modNum=0;modNum<modList.length;++modNum)
	{
		for (jobNum=0;jobNum<jobList.length;++jobNum)
		{
			if (bingusData[jobList[jobNum]][modList[modNum]] > 0) 
				{ return bingusData[jobList[jobNum]]; }
		}
	}
	// These don't have Ill variants at the moment.
	if (bingusData.cavalryParty.owned > 0) { return bingusData.cavalryParty; }
	if (bingusData.soldierParty.owned > 0) { return bingusData.soldierParty; }

	return null;
}

// Culls workers when they starve.
function starve (num) {
	var targetObj,i;
	var starveCount = 0;
	if (num === undefined) { num = 1; }
	num = Math.min(num, population.living);

	for (i=0; i<num; ++i) {
		starveCount += killUnit(pickStarveTarget());
	}
	return starveCount;
}

function doStarve() {
	var corpsesEaten, numberStarve;
	if (bingusData.food.owned < 0 && bingusData.waste.owned) // Workers eat corpses if needed
	{
		corpsesEaten = Math.min(bingusData.corpses.owned, -bingusData.food.owned);
		bingusData.corpses.owned -= corpsesEaten;
		bingusData.food.owned += corpsesEaten;
	}

	if (bingusData.food.owned < 0) { // starve if there's not enough food.
		//xxx This is very kind.  Only 0.1% deaths no matter how big the shortage?
		numberStarve = starve(Math.ceil(population.living/1000));
		if (numberStarve == 1) { 
			gameLog("A citizen starved to death"); 
		} else if (numberStarve > 1) { 
			gameLog(prettify(numberStarve) + " citizens starved to death"); 
		}
		adjustMorale(-0.01);
		bingusData.food.owned = 0;
	}
}

function killUnit (unit) {
	var killed = 0;
	if (!unit) { return 0; }

	if (unit.ill) { unit.ill -= 1; }
	else          { unit.owned -= 1; }
	
	bingusData.corpses.owned += 1; //Increments corpse number
	//Workers dying may trigger Book of the Dead
	if (bingusData.book.owned) { bingusData.piety.owned += 10; }
	calculatePopulation();
	return 1;
};


// Creates or destroys zombies
// Pass a positive number to create, a negative number to destroy.
// Only idle zombies can be destroyed.
// If it can't create/destroy as many as requested, does as many as it can.
// Pass Infinity/-Infinity as the num to get the max possible.
// Pass "custom" or "-custom" to use the custom increment.
// Returns the actual number created or destroyed (negative if destroyed).
function raiseDead(num){
	if (num === undefined) { num = 1; }
	if (num == "custom") { num = getCustomNumber(bingusData.unemployed); }
	if (num == "-custom") { num = -getCustomNumber(bingusData.unemployed); }

	// Find the most zombies we can raise
	num = Math.min(num, bingusData.corpses.owned);
	num = Math.max(num, -curBingus.zombie.owned);  // Cap firing by # in that job.
	num = Math.min(num, logSearchFn(calcZombieCost,bingusData.piety.owned));

	//Update numbers and resource levels
	bingusData.piety.owned -= calcZombieCost(num);
	curBingus.zombie.owned += num;
	bingusData.unemployed.owned += num;
	bingusData.corpses.owned -= num;

	//Notify player
	if      (num ==  1) { gameLog("A corpse rises, eager to do your bidding."); } 
	else if (num  >  1) { gameLog("The corpses rise, eager to do your bidding."); }
	else if (num == -1) { gameLog("A zombie crumples to the ground, inanimate."); }
	else if (num  < -1) { gameLog("The zombies fall, mere corpses once again."); }

	calculatePopulation(); //Run through population->jobs cycle to update page with zombie and corpse totals
	updatePopulation();
	updateResourceTotals(); //Update any piety spent

	return num;
}

function summonShade(){
	if (curBingus.enemySlain.owned <= 0) { return 0; }
	if (!payFor(bingusData.summonShade.require)) { return 0; }

	var num = Math.ceil(curBingus.enemySlain.owned/4 + (Math.random() * curBingus.enemySlain.owned/4));
	curBingus.enemySlain.owned -= num;
	bingusData.shade.owned += num;

	return num;
}

//Deity Domains upgrades
function selectDeity(domain,force){
	if (!force) {
		if (bingusData.piety.owned < 500) { return; } // Can't pay
		bingusData.piety.owned -= 500;
	}
	curBingus.deities[0].domain = domain;

	makeDeitiesTables();
	updateUpgrades();
}

function digGraves(num){
	//Creates new unfilled graves.
	curBingus.grave.owned += 100 * num;
	updatePopulation(); //Update page with grave numbers
}

function digSoulTubes(num){
	//Creates new unfilled SoulTubes.
	curBingus.soultube.owned += 100 * num;
	updatePopulation(); //Update page with grave numbers
}

//Selects a random healthy worker based on their proportions in the current job distribution.
//xxx Doesn't currently pick from the army
//xxx Take a parameter for how many people to pick.
//xxx Make this able to return multiples by returning a cost structure.
function randomHealthyWorker(){
	var num = Math.random() * population.healthy;
	var chance = 0;
	var i;
	for (i=0;i<killable.length;++i)
	{
		chance += bingusData[killable[i].id].owned;
		if (chance > num) { return killable[i].id; }
	}

	return "";
}

//Selects a random worker, kills them, and then adds a random resource
//xxx This should probably scale based on population (and maybe devotion).
function wickerman(){
	//Select a random worker
	var job = randomHealthyWorker();
	if (!job) { return; }

	//Pay the price
	if (!payFor(bingusData.wickerman.require)) { return; }
	--bingusData[job].owned;
	calculatePopulation(); //Removes killed worker

	//Select a random lootable resource
	var rewardObj = lootable[Math.floor(Math.random() * lootable.length)];

	var qty = Math.floor(Math.random() * 1000);
	//xxx Note that this presumes the price is 500 wood.
	if (rewardObj.id == "wood") { qty = (qty/2) + 500; } // Guaranteed to at least restore initial cost.
	rewardObj.owned += qty;

	function getRewardMessage(rewardObj) { switch(rewardObj.id) {
		case "food"   :  return "The crops are abundant!";
		case "death"   :  return "The deaths are rising!";
		case "wood"   :  return "The trees grow stout!";
		case "stone"  :  return "The stone splits easily!";
		case "skins"  :  return "The animals are healthy!";
		case "herbs"  :  return "The gardens flourish!"; 
		case "ore"    :  return "A new vein is struck!"; 
		case "leather":  return "The tanneries are productive!"; 
		case "metal"  :  return "The steel runs pure."; 
		default       :  return "You gain " + rewardObj.getQtyName(qty) + "!"; 
	} }

	gameLog("Burned a " + bingusData[job].getQtyName(1) + ". " + getRewardMessage(rewardObj));
	updateResourceTotals(); //Adds new resources
	updatePopulation();
}

function walk(increment){
	if (increment === undefined) { increment = 1; }
	if (increment === false) { increment = 0; bingusData.walk.rate = 0; }

	bingusData.walk.rate += increment;

	//xxx This needs to move into the main loop in case it's reloaded.
	ui.find("#walkStat").innerHTML = prettify(bingusData.walk.rate);
	ui.find("#ceaseWalk").disabled = (bingusData.walk.rate === 0);
	ui.show("#walkGroup",(bingusData.walk.rate > 0)); 
}

function tickWalk() {
	var i;
	var target = "";
	if (bingusData.walk.rate > population.healthy) { 
		bingusData.walk.rate = population.healthy; 
		ui.find("#ceaseWalk").disabled = true;
	}
	if (bingusData.walk.rate <= 0) { return; }

	for (i=0;i<bingusData.walk.rate;++i){
		target = randomHealthyWorker(); //xxx Need to modify this to do them all at once.
		if (!target){ break; } 
		--bingusData[target].owned;
	}
	updatePopulation(true);
}

// Give a temporary bonus based on the number of Bingus owned.
function pestControl(length){
	if (length === undefined) { length = 10; }
	if (bingusData.piety.owned < (10 * length)) { return; }
	bingusData.piety.owned -= (10 * length);
	bingusData.pestControl.timer = length * bingusData.bingus.owned;
	gameLog("The vermin are exterminated.");
}


/* Iconoclasm */

function iconoclasmList(){
	var i;
	//Lists the deities for removing
	if (bingusData.piety.owned >= 1000){
		bingusData.piety.owned -= 1000;
		updateResourceTotals();
		ui.find("#iconoclasm").disabled = true;
		var append = "<br />";
		for (i=1;i<curBingus.deities.length;++i){
			append += '<button onclick="iconoclasm(' + i + ')">';
			append += curBingus.deities[i].name;
			append += '</button><br />';
		}
		append += '<br /><button onclick=\'iconoclasm("cancel")\'>Cancel</button>';
		ui.find("#iconoclasmList").innerHTML = append;
	}
}

function iconoclasm(index){
	//will splice a deity from the deities array unless the user has cancelled
	ui.find("#iconoclasmList").innerHTML = "";
	ui.find("#iconoclasm").disabled = false;
	if ((index == "cancel")||(index >= curBingus.deities.length)){
		//return the piety
		bingusData.piety.owned += 1000;
		return;
	} 

	//give gold
	bingusData.gold.owned += Math.floor(Math.pow(curBingus.deities[index].maxDev,1/1.25));
	bingusData.cursedgold.owned += Math.floor(Math.pow(curBingus.deities[index].maxDev,1/1.25));

	//remove the deity
	curBingus.deities.splice(index,1);

	makeDeitiesTables();
}

/* Enemies */

function spawnMob(mobObj, num){
	var num_sge = 0, msg = "";
 
	if (num === undefined) { // By default, base numbers on current population
		var max_mob = (population.current / 50);
		num = Math.ceil(max_mob*Math.random());
	}

	if (num === 0) { return num; }  // Nobody came

	// Human mobs might bring siege engines.
	if (mobObj.species == "human") { num_sge = Math.floor(Math.random() * num/100); }

	mobObj.owned += num;
	bingusData.esiege.owned += num_sge;

	msg = prettify(num) + " " + mobObj.getQtyName(num) + " attacked";  //xxx L10N
	if (num_sge > 0) { msg += ", with " + prettify(num_sge) + " " + bingusData.esiege.getQtyName(num_sge); }  //xxx L10N 
	gameLog(msg);

	return num;
}

function smiteMob(mobObj) {
	if (!isValid(mobObj.owned) || mobObj.owned <= 0) { return 0; }
	var num = Math.min(mobObj.owned,Math.floor(bingusData.piety.owned/100));
	bingusData.piety.owned -= num * 100;
	mobObj.owned -= num;
	bingusData.corpses.owned += num; //xxx Should dead wolves count as corpses?
	curBingus.enemySlain.owned += num;
	if (bingusData.throne.owned) { bingusData.throne.count += num; }
	if (bingusData.book.owned) { bingusData.piety.owned += num * 10; }
	gameLog("Struck down " + num + " " + mobObj.getQtyName(num)); // L10N
	return num;
}

function smite(){
	smiteMob(bingusData.barbarian);
	smiteMob(bingusData.bandit);
	smiteMob(bingusData.wolf);
	updateResourceTotals();
	updateJobButtons();
}

/* War Functions */

function invade(ebingustype){
	//invades a certain type of bingusilisation based on the button clicked
	curBingus.raid.raiding = true;
	curBingus.raid.last = ebingustype;

	curBingus.raid.epop = bingusSizes[ebingustype].max_pop + 1;
	// If no max pop, use 2x min pop.
	if (curBingus.raid.epop === Infinity ) { curBingus.raid.epop = bingusSizes[ebingustype].min_pop * 2; }
	if (bingusData.glory.timer > 0) { curBingus.raid.epop *= 2; } //doubles soldiers fought

	// 5-25% of enemy population is soldiers.
	bingusData.esoldier.owned += (curBingus.raid.epop/20) + Math.floor(Math.random() * (curBingus.raid.epop/5));
	bingusData.efort.owned += Math.floor(Math.random() * (curBingus.raid.epop/5000));

	// Glory redoubles rewards (doubled here because doubled already above)
	var baseLoot = curBingus.raid.epop / (1 + (bingusData.glory.timer <= 0));

	// Set rewards of land and other random plunder.
	//xxx Maybe these should be partially proportionate to the actual number of defenders?
	curBingus.raid.plunderLoot = { 
		freeLand: Math.round(baseLoot * (1 + (bingusData.administration.owned))) 
	};
	lootable.forEach(function(elem){ curBingus.raid.plunderLoot[elem.id] = Math.round(baseLoot * Math.random()); });

	ui.hide("#raidNews");
	updateTargets(); //Hides raid buttons until the raid is finished
	updatePartyButtons(); 
}
function onInvade(control) { return invade(dataset(control,"target")); }

function plunder () {
	var plunderMsg = "";
	var raidNewsElt = ui.find("#raidNews");

	// If we fought our largest eligible foe, but not the largest possible, raise the limit.
	if ((curBingus.raid.targetMax != bingusSizes[bingusSizes.length-1].id) && curBingus.raid.last == curBingus.raid.targetMax)
	{
		curBingus.raid.targetMax = bingusSizes[bingusSizes[curBingus.raid.targetMax].idx + 1].id;
	}

	// Improve morale based on size of defeated foe.
	adjustMorale((bingusSizes[curBingus.raid.last].idx + 1)/100);

	// Lamentation
	if (bingusData.lament.owned) { curBingus.attackCounter -= Math.ceil(curBingus.raid.epop/2000); }

	// Collect loot
	payFor(curBingus.raid.plunderLoot,-1);  // We pay for -1 of these to receive them.

	// Create message to notify player
	plunderMsg = bingusSizes[curBingus.raid.last].name + " defeated! ";
	plunderMsg += "Plundered " + getReqText(curBingus.raid.plunderLoot) + ". ";
	gameLog(plunderMsg);

	ui.show(raidNewsElt, true);
	raidNewsElt.innerHTML = "Results of last raid: " + plunderMsg;

	// Victory outcome has been handled, end raid
	resetRaiding();
	updateResourceTotals();
	updateTargets();
}

function glory(time){
	if (time === undefined) { time = 180; }
	if (!payFor(bingusData.glory.require)) { return; } //check it can be bought

	bingusData.glory.timer = time; //set timer
	//xxx This needs to move into the main loop in case it's reloaded.
	ui.find("#gloryTimer").innerHTML = bingusData.glory.timer; //update timer to player
	ui.find("#gloryGroup").style.display = "block";
}

function grace(delta){
	if (delta === undefined) { delta = 0.1; }
	if (bingusData.piety.owned >= bingusData.grace.cost){
		bingusData.piety.owned -= bingusData.grace.cost;
		bingusData.grace.cost = Math.floor(bingusData.grace.cost * 1.2);
		ui.find("#graceCost").innerHTML = prettify(bingusData.grace.cost);
		adjustMorale(delta);
		updateResourceTotals();
		updateMorale();
	}
}

//xxx Eventually, we should have events like deaths affect morale (scaled by %age of total pop)
function adjustMorale(delta) {
	//Changes and updates morale given a delta value
	if (delta > 1000) {
		//console.warn("Cannot adjust morale by so much", delta);
		return;
	}
	if (population.current > 0) { //dividing by zero is bad for hive
		//calculates zombie proportion (zombies do not become happy or sad)
		var fraction = population.living / population.current;
		var max = 1 + (0.5 * fraction);
		var min = 1 - (0.5 * fraction);
		//alters morale
		curBingus.morale.efficiency += delta * fraction;
		//Then check limits (50 is median, limits are max 0 or 100, but moderated by fraction of zombies)
		if (curBingus.morale.efficiency > max){
			curBingus.morale.efficiency = max;
		} else if (curBingus.morale.efficiency < min){
			curBingus.morale.efficiency = min;
		}
		updateMorale(); //update to player
	}
}

/* Wonders functions */

function startWonder(){
	if (curBingus.curWonder.stage !== 0) { return; }
	++curBingus.curWonder.stage;
	renameWonder();
	updateWonder();
}

function renameWonder(){
	// Can't rename before you start, or after you finish.
	if (curBingus.curWonder.stage === 0 || curBingus.curWonder.stage > 2) { return; }
	var n = prompt("Please name your Wonder:",curBingus.curWonder.name);
	if (!n) { return; }
	curBingus.curWonder.name = n;
	var wp = ui.find("#wonderNameP");
	if (wp) { wp.innerHTML = curBingus.curWonder.name; }
	var wc = ui.find("#wonderNameC");
	if (wc) { wc.innerHTML = curBingus.curWonder.name; }
}

function wonderSelect(resourceId){
	if (curBingus.curWonder.stage !== 2) { return; }
	++curBingus.curWonder.stage;
	++curBingus.curWonder[resourceId];
	gameLog("You now have a permanent bonus to " + resourceId + " production.");
	curBingus.wonders.push({name: curBingus.curWonder.name, resourceId: resourceId});
	curBingus.curWonder.name = "";
	curBingus.curWonder.progress = 0;
	updateWonder();
}




/* Trade functions */

function startTrader(){
	// Set timer length (12 sec + 5 sec/upgrade)
	curBingus.trader.timer = 12 + (5 * (bingusData.currency.owned + bingusData.commerce.owned + bingusData.stay.owned));

	//then set material and requested amount
	var tradeItems = [ // Item and base amount
		{ materialId: "food",    requested: 5000 },
		{ materialId: "death",    requested: 5000 },
		{ materialId: "wood",    requested: 5000 },
		{ materialId: "stone",   requested: 5000 },
		{ materialId: "skins",   requested:  500 },
		{ materialId: "herbs",   requested:  500 },
		{ materialId: "ore",     requested:  500 },
		{ materialId: "leather", requested:  250 },
		{ materialId: "metal",   requested:  250 }
	];

	// Randomly select and merge one of the above.
	var selected = tradeItems[Math.floor(Math.random() * tradeItems.length)];
	curBingus.trader.materialId = selected.materialId;
	curBingus.trader.requested = selected.requested * (Math.ceil(Math.random() * 20)); // Up to 20x amount

	updateTrader();
}

function trade(){
	//check we have enough of the right type of resources to trade
	if (!curBingus.trader.materialId || (curBingus.trader.materialId.owned < curBingus.trader.requested)) {
		gameLog("Not enough resources to trade.");
		return;
	}

	//subtract resources, add gold
	var material = bingusData[curBingus.trader.materialId];

	material.owned -= curBingus.trader.requested;
	++bingusData.gold.owned;
	updateResourceTotals();
	gameLog("Traded " + curBingus.trader.requested + " " + material.getQtyName(curBingus.trader.requested));
}

function isTraderHere () {
	return (curBingus.trader.timer > 0);
}

function buy (materialId){
	var material = bingusData[materialId];
	if (bingusData.gold.owned < 1) { return; }
	--bingusData.gold.owned;

	if (material == bingusData.food    || material == bingusData.wood  || material == bingusData.stone    || material == bingusData.death) { material.owned += 5000; }
	if (material == bingusData.skins   || material == bingusData.herbs || material == bingusData.ore)   { material.owned +=  500; }
	if (material == bingusData.leather || material == bingusData.metal)                              { material.owned +=  250; }

	updateResourceTotals();
}

function getWonderCostMultiplier() { // Based on the most wonders in any single resource.
	var i;
	var mostWonders = 0;
	for (i in wonderCount) { if (wonderCount.hasOwnProperty(i)) { mostWonders = Math.max(mostWonders,wonderCount[i]); }}
	return Math.pow(1.5,mostWonders);
}

function speedWonder(){
	if (bingusData.gold.owned < 100) { return; }
	bingusData.gold.owned -= 100;

	curBingus.curWonder.progress += 1 / getWonderCostMultiplier();
	curBingus.curWonder.rushed = true;
	updateWonder();
}

// Game infrastructure functions

function handleStorageError(err)
{
	var msg;
	if ((err instanceof DOMException) && (err.code == DOMException.SECURITY_ERR))
		{ msg = "Browser security settings blocked access to local storage."; }
	else 
		{ msg = "Cannot access localStorage - browser may not support localStorage, or storage may be corrupt"; }
	console.error(err.toString());
	console.error(msg);
}

// Migrate an old savegame to the current format.
// settingsVarReturn is assumed to be a struct containing a property 'val',
//   which will be initialized with the new settingsVar object.
//   (We can't set the outer variable directly from within a function)
function migrateGameData(loadVar, settingsVarReturn)
{
	// BACKWARD COMPATIBILITY SECTION //////////////////
	// v1.1.35: eliminated 2nd variable
	
	// v1.1.13: population.corpses moved to corpses.total
	if (!isValid(loadVar.corpses)) { loadVar.corpses = {}; }
	if (isValid(loadVar.population) && isValid(loadVar.population.corpses)) { 
		if (!isValid(loadVar.corpses.total)) { 
			loadVar.corpses.total = loadVar.population.corpses; 
		}
		delete loadVar.population.corpses; 
	}
	// v1.1.17: population.apothecaries moved to population.healers 
	if (isValid(loadVar.population) && isValid(loadVar.population.apothecaries)) { 
		if (!isValid(loadVar.population.healers)) { 
			loadVar.population.healers = loadVar.population.apothecaries; 
		}
		delete loadVar.population.apothecaries; 
	}

	// v1.1.28: autosave changed to a bool
	loadVar.autosave = (loadVar.autosave !== false && loadVar.autosave !== "off");

	// v1.1.29: 'deity' upgrade renamed to 'worship'
	if (isValid(loadVar.upgrades) && isValid(loadVar.upgrades.deity)) { 
		if (!isValid(loadVar.upgrades.worship)) { 
			loadVar.upgrades.worship = loadVar.upgrades.deity; 
		}
		delete loadVar.upgrades.deity;
	}
	// v1.1.30: Upgrade flags converted from int to bool (should be transparent)
	// v1.1.31: deity.devotion moved to devotion.total.
	if (!isValid(loadVar.devotion)) { loadVar.devotion = {}; }
	if (isValid(loadVar.deity) && isValid(loadVar.deity.devotion)) { 
		if (!isValid(loadVar.devotion.total)) { 
			loadVar.devotion.total = loadVar.deity.devotion; 
		}
		delete loadVar.deity.devotion; 
	}
	// v1.1.33: Achievement flags converted from int to bool (should be transparent)
	// v1.1.33: upgrades.deityType no longer used
	if (isValid(loadVar.upgrades)) { delete loadVar.upgrades.deityType; }

	// v1.1.34: Most efficiency values now recomputed from base values.
	if (isValid(loadVar.efficiency)) {
		loadVar.efficiency = {happiness: loadVar.efficiency.happiness };
	}
	
	// v1.1.38: Most assets moved to curBingus substructure
	if (!isValid(loadVar.curBingus)) { 
		loadVar.curBingus = {
			bingusName: loadVar.bingusName,
			rulerName: loadVar.rulerName,

			// Migrate resources
			food : { owned:loadVar.food.total, net:(loadVar.food.net||0) },
			death : { owned:loadVar.death.total, net:(loadVar.death.net||0) },
			wood : { owned:loadVar.wood.total, net:(loadVar.wood.net||0) },
			stone : { owned:loadVar.stone.total, net:(loadVar.stone.net||0) },
			skins : { owned:loadVar.skins.total },
			herbs : { owned:loadVar.herbs.total },
			ore : { owned:loadVar.ore.total },
			leather : { owned:loadVar.leather.total },
			metal : { owned:loadVar.metal.total },
			piety : { owned:loadVar.piety.total },
			gold : { owned:loadVar.gold.total },
			corpses : { owned:loadVar.corpses.total },
			devotion : { owned:loadVar.devotion.total },

			// land (total land) is now stored as free land, so do that calculation.
			freeLand: { owned: loadVar.land - ( loadVar.tent.total + loadVar.whut.total + loadVar.cottage.total 
			+ loadVar.house.total + loadVar.mansion.total + loadVar.barn.total + loadVar.hell.total + loadVar.woodstock.total
			+ loadVar.bloodwoodstock.total + loadVar.hell.total + loadVar.stonestock.total + loadVar.bloodstonestock.total + loadVar.tannery.total + loadVar.smithy.total + loadVar.apothecary.total 
			+ loadVar.temple.total + loadVar.barracks.total + loadVar.stable.total + loadVar.mill.total 
			+ loadVar.power.total + loadVar.graveyard.total + loadVar.fortification.total + loadVar.battleAltar.total 
			+ loadVar.fieldsAltar.total + loadVar.underworldAltar.total + loadVar.bingusAltar.total + loadVar.satanAltar.total) },

			// Migrate buildings
			tent : { owned:loadVar.tent.total },
			// Hut ID also changed from 'whut' to 'hut'.
			hut : { owned:loadVar.whut.total },
			cottage : { owned:loadVar.cottage.total },
			house : { owned:loadVar.house.total },
			mansion : { owned:loadVar.mansion.total },
			barn : { owned:loadVar.barn.total },
			hell : { owned:loadVar.hell.total },
			woodstock : { owned:loadVar.woodstock.total },
			stonestock : { owned:loadVar.stonestock.total },
			bloodwoodstock : { owned:loadVar.bloodwoodstock.total },
			bloodstonestock : { owned:loadVar.bloodstonestock.total },
			tannery : { owned:loadVar.tannery.total },
			smithy : { owned:loadVar.smithy.total },
			apothecary : { owned:loadVar.apothecary.total },
			temple : { owned:loadVar.temple.total },
			barracks : { owned:loadVar.barracks.total },
			stable : { owned:loadVar.stable.total },
			mill : { owned:loadVar.mill.total },
			power : { owned:loadVar.power.total },
			graveyard : { owned:loadVar.graveyard.total },
			fortification : { owned:loadVar.fortification.total },
			battleAltar : { owned:loadVar.battleAltar.total },
			fieldsAltar : { owned:loadVar.fieldsAltar.total },
			underworldAltar : { owned:loadVar.underworldAltar.total },
			bingusAltar : { owned:loadVar.bingusAltar.total },
			satanAltar : { owned:loadVar.satanAltar.total }
		}; 
		// Delete old values.
		delete loadVar.bingusName;
		delete loadVar.rulerName;
		delete loadVar.food;
		delete loadVar.death;
		delete loadVar.wood;
		delete loadVar.stone;
		delete loadVar.skins;
		delete loadVar.herbs;
		delete loadVar.bloodwood;
		delete loadVar.bloodstone;
		delete loadVar.souls;
		delete loadVar.bloodherbs;
		delete loadVar.ore;
		delete loadVar.leather;
		delete loadVar.metal;
		delete loadVar.piety;
		delete loadVar.gold;
		delete loadVar.corpses;
		delete loadVar.devotion;
		delete loadVar.land;
		delete loadVar.tent;
		delete loadVar.whut;
		delete loadVar.cottage;
		delete loadVar.house;
		delete loadVar.mansion;
		delete loadVar.barn;
		delete loadVar.woodstock;
		delete loadVar.stonestock;
		delete loadVar.hell;
		delete loadVar.bloodwoodstock;
		delete loadVar.bloodstonestock;
		delete loadVar.tannery;
		delete loadVar.smithy;
		delete loadVar.apothecary;
		delete loadVar.temple;
		delete loadVar.barracks;
		delete loadVar.stable;
		delete loadVar.mill;
		delete loadVar.power;
		delete loadVar.graveyard;
		delete loadVar.fortification;
		delete loadVar.battleAltar;
		delete loadVar.fieldsAltar;
		delete loadVar.underworldAltar;
		delete loadVar.bingusAltar;
		delete loadVar.satanAltar;
	}

	if (isValid(loadVar.evilupgrades)) {
		// Migrate upgrades

		// Evil Upgrades
		loadVar.curBingus.satanic = { owned:loadVar.evilupgrades.satanic };
		loadVar.curBingus.collecting = { owned:loadVar.evilupgrades.collecting };
		loadVar.curBingus.satans = { owned:loadVar.evilupgrades.satans };
		loadVar.curBingus.evilpalisade = { owned:loadVar.evilupgrades.evilpalisade };
		loadVar.curBingus.evilweaponry = { owned:loadVar.evilupgrades.evilweaponry };
		loadVar.curBingus.evilshields = { owned:loadVar.evilupgrades.evilshields };
		loadVar.curBingus.evilhorseback = { owned:loadVar.evilupgrades.evilhorseback };
		loadVar.curBingus.evilwriting = { owned:loadVar.evilupgrades.evilwriting };
		loadVar.curBingus.eviladministration = { owned:loadVar.evilupgrades.eviladministration };
		loadVar.curBingus.evilcodeoflaws = { owned:loadVar.evilupgrades.evilcodeoflaws };
		loadVar.curBingus.evilmathematics = { owned:loadVar.evilupgrades.evilmathematics };
		loadVar.curBingus.evilaesthetics = { owned:loadVar.evilupgrades.evilaesthetics };
		loadVar.curBingus.evilprospecting = { owned:loadVar.evilupgrades.evilprospecting };
		loadVar.curBingus.evildomestication = { owned:loadVar.evilupgrades.evildomestication };
		loadVar.curBingus.evilploughshares = { owned:loadVar.evilupgrades.evilploughshares };
		loadVar.curBingus.evilirrigation = { owned:loadVar.evilupgrades.evilirrigation };
		loadVar.curBingus.evilbutchering = { owned:loadVar.evilupgrades.evilbutchering };
		loadVar.curBingus.evilgardening = { owned:loadVar.evilupgrades.evilgardening };
		loadVar.curBingus.evilextraction = { owned:loadVar.evilupgrades.evilextraction };
		loadVar.curBingus.evilmacerating = { owned:loadVar.evilupgrades.evilmacerating };
		loadVar.curBingus.soulsrotation = { owned:loadVar.evilupgrades.soulsrotation };
		loadVar.curBingus.evilselectivebreeding = { owned:loadVar.evilupgrades.evilselectivebreeding };
		loadVar.curBingus.evilfertilisers = { owned:loadVar.evilupgrades.evilfertilisers };
		loadVar.curBingus.evilmasonry = { owned:loadVar.evilupgrades.evilmasonry };
		loadVar.curBingus.evilconstruction = { owned:loadVar.evilupgrades.evilconstruction };
		loadVar.curBingus.evilarchitecture = { owned:loadVar.evilupgrades.evilarchitecture };
		loadVar.curBingus.eviltenements = { owned:loadVar.evilupgrades.eviltenements };
		loadVar.curBingus.evilslums = { owned:loadVar.evilupgrades.evilslums };
		loadVar.curBingus.bloodwheel = { owned:loadVar.evilupgrades.bloodwheel };
		loadVar.curBingus.evilfeudalism = { owned:loadVar.evilupgrades.evilfeudalism };
		loadVar.curBingus.evilguilds = { owned:loadVar.evilupgrades.evilguilds };
		loadVar.curBingus.evilserfs = { owned:loadVar.evilupgrades.evilserfs };
		loadVar.curBingus.evilnationalism = { owned:loadVar.evilupgrades.evilnationalism };
		delete loadVar.evilupgrades;
	}

	if (isValid(loadVar.upgrades)) {
		// Migrate upgrades
		
		//normal upgrades
		loadVar.curBingus.skinning = { owned:loadVar.upgrades.skinning };
		loadVar.curBingus.harvesting = { owned:loadVar.upgrades.harvesting };
		loadVar.curBingus.prospecting = { owned:loadVar.upgrades.prospecting };
		loadVar.curBingus.domestication = { owned:loadVar.upgrades.domestication };
		loadVar.curBingus.ploughshares = { owned:loadVar.upgrades.ploughshares };
		loadVar.curBingus.irrigation = { owned:loadVar.upgrades.irrigation };
		loadVar.curBingus.butchering = { owned:loadVar.upgrades.butchering };
		loadVar.curBingus.gardening = { owned:loadVar.upgrades.gardening };
		loadVar.curBingus.extraction = { owned:loadVar.upgrades.extraction };
		loadVar.curBingus.flensing = { owned:loadVar.upgrades.flensing };
		loadVar.curBingus.macerating = { owned:loadVar.upgrades.macerating };
		loadVar.curBingus.croprotation = { owned:loadVar.upgrades.croprotation };
		loadVar.curBingus.selectivebreeding = { owned:loadVar.upgrades.selectivebreeding };
		loadVar.curBingus.fertilisers = { owned:loadVar.upgrades.fertilisers };
		loadVar.curBingus.masonry = { owned:loadVar.upgrades.masonry };
		loadVar.curBingus.construction = { owned:loadVar.upgrades.construction };
		loadVar.curBingus.architecture = { owned:loadVar.upgrades.architecture };
		loadVar.curBingus.tenements = { owned:loadVar.upgrades.tenements };
		loadVar.curBingus.slums = { owned:loadVar.upgrades.slums };
		loadVar.curBingus.granaries = { owned:loadVar.upgrades.granaries };
		loadVar.curBingus.palisade = { owned:loadVar.upgrades.palisade };
		loadVar.curBingus.weaponry = { owned:loadVar.upgrades.weaponry };
		loadVar.curBingus.shields = { owned:loadVar.upgrades.shields };
		loadVar.curBingus.horseback = { owned:loadVar.upgrades.horseback };
		loadVar.curBingus.wheel = { owned:loadVar.upgrades.wheel };
		loadVar.curBingus.writing = { owned:loadVar.upgrades.writing };
		loadVar.curBingus.administration = { owned:loadVar.upgrades.administration };
		loadVar.curBingus.codeoflaws = { owned:loadVar.upgrades.codeoflaws };
		loadVar.curBingus.mathematics = { owned:loadVar.upgrades.mathematics };
		loadVar.curBingus.aesthetics = { owned:loadVar.upgrades.aesthetics };
		loadVar.curBingus.bingusservice = { owned:loadVar.upgrades.bingusservice };
		loadVar.curBingus.feudalism = { owned:loadVar.upgrades.feudalism };
		loadVar.curBingus.guilds = { owned:loadVar.upgrades.guilds };
		loadVar.curBingus.serfs = { owned:loadVar.upgrades.serfs };
		loadVar.curBingus.nationalism = { owned:loadVar.upgrades.nationalism };
		loadVar.curBingus.worship = { owned:loadVar.upgrades.worship };
		loadVar.curBingus.lure = { owned:loadVar.upgrades.lure };
		loadVar.curBingus.companion = { owned:loadVar.upgrades.companion };
		loadVar.curBingus.comfort = { owned:loadVar.upgrades.comfort };
		loadVar.curBingus.blessing = { owned:loadVar.upgrades.blessing };
		loadVar.curBingus.waste = { owned:loadVar.upgrades.waste };
		loadVar.curBingus.stay = { owned:loadVar.upgrades.stay };
		loadVar.curBingus.riddle = { owned:loadVar.upgrades.riddle };
		loadVar.curBingus.throne = { owned:loadVar.upgrades.throne };
		loadVar.curBingus.lament = { owned:loadVar.upgrades.lament };
		loadVar.curBingus.book = { owned:loadVar.upgrades.book };
		loadVar.curBingus.feast = { owned:loadVar.upgrades.feast };
		loadVar.curBingus.secrets = { owned:loadVar.upgrades.secrets };
		loadVar.curBingus.standard = { owned:loadVar.upgrades.standard };
		loadVar.curBingus.trade = { owned:loadVar.upgrades.trade };
		loadVar.curBingus.currency = { owned:loadVar.upgrades.currency };
		loadVar.curBingus.commerce = { owned:loadVar.upgrades.commerce };
		delete loadVar.upgrades;
	}

	if (isValid(loadVar.evilachievements)) {
		// Migrate achievements
		// Evil Achievements
		loadVar.curBingus.hellAch = { owned:loadVar.evilachievements.hell };
		loadVar.curBingus.satanAch = { owned:loadVar.evilachievements.satan };
		loadVar.curBingus.satanAch2 = { owned:loadVar.evilachievements.satan2 };
		delete loadVar.evilachievements;
	}


	if (isValid(loadVar.achievements)) {
		// Migrate achievements

		// Normal Achievements
		loadVar.curBingus.hamletAch = { owned:loadVar.achievements.hamlet };
		loadVar.curBingus.villageAch = { owned:loadVar.achievements.village };
		loadVar.curBingus.smallTownAch = { owned:loadVar.achievements.smallTown };
		loadVar.curBingus.largeTownAch = { owned:loadVar.achievements.largeTown };
		loadVar.curBingus.smallCityAch = { owned:loadVar.achievements.smallCity };
		loadVar.curBingus.largeCityAch = { owned:loadVar.achievements.largeCity };
		loadVar.curBingus.metropolisAch = { owned:loadVar.achievements.metropolis };
		loadVar.curBingus.smallNationAch = { owned:loadVar.achievements.smallNation };
		loadVar.curBingus.nationAch = { owned:loadVar.achievements.nation };
		loadVar.curBingus.largeNationAch = { owned:loadVar.achievements.largeNation };
		loadVar.curBingus.empireAch = { owned:loadVar.achievements.empire };
		loadVar.curBingus.raiderAch = { owned:loadVar.achievements.raider };
		loadVar.curBingus.engineerAch = { owned:loadVar.achievements.engineer };
		loadVar.curBingus.dominationAch = { owned:loadVar.achievements.domination };
		loadVar.curBingus.hatedAch = { owned:loadVar.achievements.hated };
		loadVar.curBingus.lovedAch = { owned:loadVar.achievements.loved };
		loadVar.curBingus.bingusAch = { owned:loadVar.achievements.bingus };
		loadVar.curBingus.glaringAch = { owned:loadVar.achievements.glaring };
		loadVar.curBingus.clowderAch = { owned:loadVar.achievements.clowder };
		loadVar.curBingus.battleAch = { owned:loadVar.achievements.battle };
		loadVar.curBingus.bingusAch = { owned:loadVar.achievements.bingus };
		loadVar.curBingus.fieldsAch = { owned:loadVar.achievements.fields };
		loadVar.curBingus.underworldAch = { owned:loadVar.achievements.underworld };
		loadVar.curBingus.fullHouseAch = { owned:loadVar.achievements.fullHouse };
		// ID 'plague' changed to 'plagued'.
		loadVar.curBingus.plaguedAch = { owned:loadVar.achievements.plague };
		loadVar.curBingus.ghostTownAch = { owned:loadVar.achievements.ghostTown };
		loadVar.curBingus.wonderAch = { owned:loadVar.achievements.wonder };
		loadVar.curBingus.sevenAch = { owned:loadVar.achievements.seven };
		loadVar.curBingus.merchantAch = { owned:loadVar.achievements.merchant };
		loadVar.curBingus.rushedAch = { owned:loadVar.achievements.rushed };
		loadVar.curBingus.neverclickAch = { owned:loadVar.achievements.neverclick };
		delete loadVar.achievements;
	}

	if (isValid(loadVar.evilpopulation)) {
		// Migrate population
		/ Evil Population
		loadVar.curBingus.blood = { owned:loadVar.evilpopulation.blood };
		loadVar.curBingus.soultube = { owned:loadVar.evilpopulation.soultube };
		loadVar.curBingus.satan = { owned:loadVar.evilpopulation.satan };
		loadVar.curBingus.bloodwoodcutter = { owned:loadVar.evilpopulation.bloodwoodcutters };
		loadVar.curBingus.bloodminer = { owned:loadVar.evilpopulation.bloodminers };
		loadVar.curBingus.evilblacksmith = { owned:loadVar.evilpopulation.evilblacksmiths };
		loadVar.curBingus.evilsoldier = { owned:loadVar.evilpopulation.evilsoldiers };
		loadVar.curBingus.evilsoldierParty = { owned:loadVar.evilpopulation.evilsoldiersParty };
		loadVar.curBingus.satanIll = { owned:loadVar.evilpopulation.satanIll };
		loadVar.curBingus.bloodwoodcutterIll = { owned:loadVar.evilpopulation.bloodwoodcuttersIll };
		loadVar.curBingus.bloodminerIll = { owned:loadVar.evilpopulation.bloodminersIll };
		loadVar.curBingus.evilblacksmithIll = { owned:loadVar.evilpopulation.evilblacksmithsIll };
		loadVar.curBingus.evilsoldierIll = { owned:loadVar.evilpopulation.evilsoldiersIll };
		delete loadVar.evilpopulation;
	}


	if (isValid(loadVar.population)) {
		// Migrate population
		// Normal Population
		loadVar.curBingus.bingus = { owned:loadVar.population.bingus };
		loadVar.curBingus.zombie = { owned:loadVar.population.zombies };
		loadVar.curBingus.grave = { owned:loadVar.population.graves };
		loadVar.curBingus.unemployed = { owned:loadVar.population.unemployed };
		loadVar.curBingus.farmer = { owned:loadVar.population.farmers };
		loadVar.curBingus.woodcutter = { owned:loadVar.population.woodcutters };
		loadVar.curBingus.miner = { owned:loadVar.population.miners };
		loadVar.curBingus.tanner = { owned:loadVar.population.tanners };
		loadVar.curBingus.blacksmith = { owned:loadVar.population.blacksmiths };
		loadVar.curBingus.healer = { owned:loadVar.population.healers };
		loadVar.curBingus.cleric = { owned:loadVar.population.clerics };
		loadVar.curBingus.labourer = { owned:loadVar.population.labourers };
		loadVar.curBingus.soldier = { owned:loadVar.population.soldiers };
		loadVar.curBingus.cavalry = { owned:loadVar.population.cavalry };
		loadVar.curBingus.soldierParty = { owned:loadVar.population.soldiersParty };
		loadVar.curBingus.cavalryParty = { owned:loadVar.population.cavalryParty };
		loadVar.curBingus.siege = { owned:loadVar.population.siege };
		loadVar.curBingus.esoldier = { owned:loadVar.population.esoldiers };
		loadVar.curBingus.efort = { owned:loadVar.population.eforts };
		loadVar.curBingus.unemployedIll = { owned:loadVar.population.unemployedIll };
		loadVar.curBingus.farmerIll = { owned:loadVar.population.farmersIll };
		loadVar.curBingus.woodcutterIll = { owned:loadVar.population.woodcuttersIll };
		loadVar.curBingus.minerIll = { owned:loadVar.population.minersIll };
		loadVar.curBingus.tannerIll = { owned:loadVar.population.tannersIll };
		loadVar.curBingus.blacksmithIll = { owned:loadVar.population.blacksmithsIll };
		loadVar.curBingus.healerIll = { owned:loadVar.population.healersIll };
		loadVar.curBingus.clericIll = { owned:loadVar.population.clericsIll };
		loadVar.curBingus.labourerIll = { owned:loadVar.population.labourersIll };
		loadVar.curBingus.soldierIll = { owned:loadVar.population.soldiersIll };
		loadVar.curBingus.cavalryIll = { owned:loadVar.population.cavalryIll };
		loadVar.curBingus.wolf = { owned:loadVar.population.wolves };
		loadVar.curBingus.bandit = { owned:loadVar.population.bandits };
		loadVar.curBingus.barbarian = { owned:loadVar.population.barbarians };
		loadVar.curBingus.esiege = { owned:loadVar.population.esiege };
		loadVar.curBingus.enemySlain = { owned:loadVar.population.enemiesSlain };
		loadVar.curBingus.shade = { owned:loadVar.population.shades };
		delete loadVar.population;
	}

	// v1.1.38: Game settings moved to settings object, but we deliberately
	// don't try to migrate them.  'autosave', 'worksafe', and 'fontSize'
	// values from earlier versions will be discarded.

	// v1.1.39: Migrate more save fields into curBingus.
	if (isValid(loadVar.resourceClicks)){ 
		loadVar.curBingus.resourceClicks = loadVar.resourceClicks;
		delete loadVar.resourceClicks;
	}
	if (!isValid(loadVar.curBingus.resourceClicks)){
		loadVar.curBingus.resourceClicks = 999; //stops people getting the achievement with an old save version
	}
	if (isValid(loadVar.graceCost)){ 
		loadVar.curBingus.graceCost = loadVar.graceCost;
		delete loadVar.graceCost;
	}
	if (isValid(loadVar.walkTotal)){ 
		loadVar.curBingus.walkTotal = loadVar.walkTotal;
		delete loadVar.walkTotal;
	}

	// v1.1.39: Migrate deities to use IDs.
	if (isValid(loadVar.deityArray))
	{
		loadVar.curBingus.deities = [];
		loadVar.deityArray.forEach(function(row) {
			loadVar.curBingus.deities.unshift({ name: row[1], domain: typeToId(row[2]), maxDev: row[3] });
		});
		delete loadVar.deityArray;
	}

	if (isValid(loadVar.deity) && isValid(loadVar.curBingus.devotion))
	{
		loadVar.curBingus.deities.unshift({ name: loadVar.deity.name, domain: typeToId(loadVar.deity.type), maxDev: loadVar.curBingus.devotion.owned });
		delete loadVar.deity;
	}

	// v1.1.39: Settings moved to their own variable
	if (isValid(loadVar.settings))
	{
		settingsVarReturn.val = loadVar.settings;
		delete loadVar.settings;
	}

	// v1.1.39: Raiding now stores enemy population instead of 'iterations'.
	if (isValid(loadVar.raiding) && isValid(loadVar.raiding.iterations))
	{
		loadVar.raiding.epop = loadVar.raiding.iterations * 20;
		// Plunder calculations now moved to the start of the raid.
		// This should rarely happen, but give a consolation prize.
		loadVar.raiding.plunderLoot = { gold: 1 };
		delete loadVar.raiding.iterations;
	}

	if (isValid(loadVar.throneCount)) // v1.1.55: Moved to substructure
	{
		if (!isValid(loadVar.curBingus.throne)) { loadVar.curBingus.throne = {}; }
		loadVar.curBingus.throne.count = loadVar.throneCount||0;
		delete loadVar.throneCount;
	}

	if (isValid(loadVar.gloryTimer)) // v1.1.55: Moved to substructure
	{
		if (!isValid(loadVar.curBingus.glory)) { loadVar.curBingus.glory = {}; }
		loadVar.curBingus.glory.timer = loadVar.gloryTimer||0;
		delete loadVar.gloryTimer;
	}

	if (isValid(loadVar.walkTotal)) // v1.1.55: Moved to substructure
	{
		if (!isValid(loadVar.curBingus.walk)) { loadVar.curBingus.walk = {}; }
		loadVar.curBingus.walk.rate = loadVar.walkTotal||0;
		delete loadVar.walkTotal;
	}

	if (isValid(loadVar.pestTimer)) // v1.1.55: Moved to substructure
	{
		if (!isValid(loadVar.curBingus.pestControl)) { loadVar.curBingus.pestControl = {}; }
		loadVar.curBingus.pestControl.timer = loadVar.pestTimer||0;
		delete loadVar.pestTimer;
	}

	if (isValid(loadVar.graceCost)) // v1.1.55: Moved to substructure
	{
		if (!isValid(loadVar.curBingus.grace)) { loadVar.curBingus.grace = {}; }
		loadVar.curBingus.grace.cost = loadVar.graceCost||1000;
		delete loadVar.graceCost;
	}

	if (isValid(loadVar.cureCounter)) // v1.1.55: Moved to substructure
	{
		if (!isValid(loadVar.curBingus.healer)) { loadVar.curBingus.healer = {}; }
		loadVar.curBingus.healer.cureCount = loadVar.cureCounter||0;
		delete loadVar.cureCounter;
	}

	if (isValid(loadVar.efficiency)) // v1.1.59: efficiency.happiness moved to curBingus.morale.efficiency.
	{
		if (!isValid(loadVar.curBingus.morale)) { loadVar.curBingus.morale = {}; }
		loadVar.curBingus.morale.efficiency = loadVar.efficiency.happiness||1.0;
		delete loadVar.efficiency; // happiness was the last remaining efficiency subfield.
	}

	if (isValid(loadVar.raiding)) // v1.1.59: raiding moved to curBingus.raid
	{
		if (!isValid(loadVar.curBingus.raid)) { loadVar.curBingus.raid = loadVar.raiding; }
		delete loadVar.raiding;
	}

	if (isValid(loadVar.targetMax)) // v1.1.59: targeMax moved to curBingus.raid.targetMax
	{
		if (!isValid(loadVar.curBingus.raid)) { loadVar.curBingus.raid = {}; }
		loadVar.curBingus.raid.targetMax = loadVar.targetMax;
		delete loadVar.targetMax;
	}

	if (isValid(loadVar.curBingus.tradeCounter)) // v1.1.59: curBingus.tradeCounter moved to curBingus.trader.counter
	{
		if (!isValid(loadVar.curBingus.trader)) { loadVar.curBingus.trader = {}; }
		loadVar.curBingus.trader.counter = loadVar.curBingus.tradeCounter||0;
		delete loadVar.curBingus.tradeCounter;
	}

	if (isValid(loadVar.wonder.array)) // v1.1.59: wonder.array moved to curBingus.wonders
	{
		if (!isValid(loadVar.curBingus.wonders)) { 
			loadVar.curBingus.wonders = [];
			loadVar.wonder.array.forEach(function(elem) {
				// Format converted from [name,resourceId] to {name: name, resourceId: resourceId}
				loadVar.curBingus.wonders.push({name: elem[0], resourceId: elem[1]});
			});
		}
		delete loadVar.wonder.array;
	}

	if (isValid(loadVar.wonder)) // v1.1.59: wonder moved to curBingus.curWonder
	{
		if (isValid(loadVar.wonder.total  )) { delete loadVar.wonder.total;   } // wonder.total no longer used.
		if (isValid(loadVar.wonder.food   )) { delete loadVar.wonder.food;    } // wonder.food no longer used.
		if (isValid(loadVar.wonder.death   )) { delete loadVar.wonder.death;    } // wonder.death no longer used.
		if (isValid(loadVar.wonder.wood   )) { delete loadVar.wonder.wood;    } // wonder.wood no longer used.
		if (isValid(loadVar.wonder.stone  )) { delete loadVar.wonder.stone;   } // wonder.stone no longer used.
		if (isValid(loadVar.wonder.skins  )) { delete loadVar.wonder.skins;   } // wonder.skins no longer used.
		if (isValid(loadVar.wonder.herbs  )) { delete loadVar.wonder.herbs;   } // wonder.herbs no longer used.
		if (isValid(loadVar.wonder.ore    )) { delete loadVar.wonder.ore;     } // wonder.ore no longer used.
		if (isValid(loadVar.wonder.leather)) { delete loadVar.wonder.leather; } // wonder.leather no longer used.
		if (isValid(loadVar.wonder.piety  )) { delete loadVar.wonder.piety;   } // wonder.piety no longer used.
		if (isValid(loadVar.wonder.metal  )) { delete loadVar.wonder.metal;   } // wonder.metal no longer used.
		if (isValid(loadVar.wonder.bloodwood   )) { delete loadVar.wonder.bloodwood;    } // wonder.wood no longer used.
		if (isValid(loadVar.wonder.bloodstone  )) { delete loadVar.wonder.bloodstone;   } // wonder.stone no longer used.
		if (isValid(loadVar.wonder.souls  )) { delete loadVar.wonder.souls;   } // wonder.skins no longer used.
		if (isValid(loadVar.wonder.bloodherbs  )) { delete loadVar.wonder.bloodherbs;   } // wonder.herbs no longer used.
		if (isValid(loadVar.wonder.acidore    )) { delete loadVar.wonder.acidore;     } // wonder.ore no longer used.
		if (isValid(loadVar.wonder.cursedleather)) { delete loadVar.wonder.cursedleather; } // wonder.leather no longer used.
		if (isValid(loadVar.wonder.bloodpiety  )) { delete loadVar.wonder.bloodpiety;   } // wonder.piety no longer used.
		if (isValid(loadVar.wonder.acidmetal  )) { delete loadVar.wonder.acidmetal;   } // wonder.metal no longer used.
		if (!isValid(loadVar.wonder.stage) && isValid(loadVar.wonder.building) && isValid(loadVar.wonder.completed)) {
			// This ugly formula merges the 'building' and 'completed' fields into 'stage'.
			loadVar.wonder.stage = (2*loadVar.wonder.completed) + (loadVar.wonder.building != loadVar.wonder.completed);
			delete loadVar.wonder.building;
			delete loadVar.wonder.completed;
		}
		if (!isValid(loadVar.curBingus.curWonder)) { loadVar.curBingus.curWonder = loadVar.wonder; }
		delete loadVar.wonder;
	}
	////////////////////////////////////////////////////
}

// Load in saved data
function load (loadType) {
	//define load variables
	var loadVar = {},
		loadVar2 = {},
		settingsVar = {};
	var saveVersion = new VersionData(1,0,0,"legacy");

	if (loadType === "cookie") {
		//check for cookies
		if (read_cookie(saveTag) && read_cookie(saveTag2)){
			//set variables to load from
			loadVar = read_cookie(saveTag);
			loadVar2 = read_cookie(saveTag2);
			loadVar = mergeObj(loadVar, loadVar2);
			loadVar2 = undefined;
			//notify user
			gameLog("Loaded saved game from cookie");
			gameLog("Save system switching to localStorage.");
		} else {
			console.log("Unable to find cookie");
			return false;
		}
	}
	
	if (loadType === "localStorage") {
		//check for local storage
		var string1;
		var string2;
		var settingsString;
		try {
			settingsString = localStorage.getItem(saveSettingsTag);
			string1 = localStorage.getItem(saveTag);
			string2 = localStorage.getItem(saveTag2);

			if (!string1) {
				console.log("Unable to find variables in localStorage. Attempting to load cookie.");
				return load("cookie");
			}

		} catch(err) {
			if (!string1) { // It could be fine if string2 or settingsString fail.
				handleStorageError(err);
				return load("cookie");
			}
		}
		
		// Try to parse the strings
		if (string1) { try { loadVar  = JSON.parse(string1); } catch(ignore){} }
		if (string2) { try { loadVar2 = JSON.parse(string2); } catch(ignore){} }
		if (settingsString) { try { settingsVar = JSON.parse(settingsString); } catch(ignore){} }

		// If there's a second string (old save game format), merge it in.
		if (loadVar2) { loadVar = mergeObj(loadVar, loadVar2); loadVar2 = undefined; }

		if (!loadVar) {
			console.log("Unable to parse variables in localStorage. Attempting to load cookie.");
			return load("cookie");
		}

		//notify user
		gameLog("Loaded saved game from localStorage");
	}
	
	if (loadType === "import") {
		loadVar = importByInput(ui.find("#impexpField"));
	}

	saveVersion = mergeObj(saveVersion, loadVar.versionData);
	if (saveVersion.toNumber() > versionData.toNumber()) {
		// Refuse to load saved games from future versions.
		var alertStr = "Cannot load; saved game version " + saveVersion + " is newer than game version " + versionData;
		console.log(alertStr);
		alert(alertStr);
		return false;
	} 
	if (saveVersion.toNumber() < versionData.toNumber()) {
		// Migrate saved game data from older versions.
		var settingsVarReturn = { val: {} };
		migrateGameData(loadVar, settingsVarReturn);
		settingsVar = settingsVarReturn.val;

		// Merge the loaded data into our own, in case we've added fields.
		mergeObj(curBingus, loadVar.curBingus);
	} else {
		curBingus = loadVar.curBingus; // No need to merge if the versions match; this is quicker.
	}

	console.log("Loaded save game version " + saveVersion.major +
		"." + saveVersion.minor + "." + saveVersion.sub + "(" + saveVersion.mod + ") via", loadType);

	if (isValid(settingsVar)){ settings = mergeObj(settings,settingsVar); }
 
	adjustMorale(0);
	updateRequirements(bingusData.mill);
	updateRequirements(bingusData.power);
	updateRequirements(bingusData.fortification);
	updateRequirements(bingusData.battleAltar);
	updateRequirements(bingusData.fieldsAltar);
	updateRequirements(bingusData.underworldAltar);
	updateRequirements(bingusData.bingusAltar);
	updateRequirements(bingusData.bloodAltar);
	updateResourceTotals();
	updateJobButtons();
	updateEvilJobButtons();
	makeDeitiesTables();
	updateDeity();
	updateUpgrades();
	updateEvilUpgrades();
	updateTargets();
	updateDevotion();
	updatePartyButtons();
	updateMorale();
	updateWonder();
	tallyWonderCount();
	ui.find("#clicks").innerHTML = prettify(Math.round(curBingus.resourceClicks));
	ui.find("#bingusName").innerHTML = curBingus.bingusName;
	ui.find("#rulerName").innerHTML = curBingus.rulerName;
	ui.find("#wonderNameP").innerHTML = curBingus.curWonder.name;
	ui.find("#wonderNameC").innerHTML = curBingus.curWonder.name;

	return true;
}

function importByInput (elt) {
	//take the import string, decompress and parse it
	var compressed = elt.value;
	var decompressed = LZString.decompressFromBase64(compressed);
	var revived = JSON.parse(decompressed);
	//set variables to load from
	var loadVar = revived[0];
	var loadVar2;
	if (isValid(revived[1])) {
		loadVar2 = revived[1];
		// If there's a second string (old save game format), merge it in.
		if (loadVar2) { loadVar = mergeObj(loadVar, loadVar2); loadVar2 = undefined; }
	}
	if (!loadVar) {
		console.log("Unable to parse saved game string.");
		return false;
	}

	//notify user
	gameLog("Imported saved game");
	//close import/export dialog
	//impexp();	
	return loadVar;
}

// Create objects and populate them with the variables, these will be stored in HTML5 localStorage.
// Cookie-based saves are no longer supported.
function save(savetype){
	var xmlhttp;

	var saveVar = {
		versionData:versionData, // Version information header
		curBingus:curBingus // Game data
	};

	var settingsVar = settings; // UI Settings are saved separately.

	////////////////////////////////////////////////////

	// Handle export
	if (savetype == "export"){
		var savestring = "[" + JSON.stringify(saveVar) + "]";
		var compressed = LZString.compressToBase64(savestring);
		console.log("Compressed save from " + savestring.length + " to " + compressed.length + " characters");
		ui.find("#impexpField").value = compressed;
		gameLog("Exported game to text");
		return true;
	}

	//set localstorage
	try {
		// Delete the old cookie-based save to avoid mismatched saves
		deleteCookie(saveTag);
		deleteCookie(saveTag2);

		localStorage.setItem(saveTag, JSON.stringify(saveVar));

		// We always save the game settings.
		localStorage.setItem(saveSettingsTag, JSON.stringify(settingsVar));

		//Update console for debugging, also the player depending on the type of save (manual/auto)
		if (savetype == "auto"){
			console.log("Autosave");
			gameLog("Autosaved");
		} else if (savetype == "manual"){
			alert("Game Saved");
			console.log("Manual Save");
			gameLog("Saved game");
		}
	} catch(err) {
		handleStorageError(err);

		if (savetype == "auto"){
			console.log("Autosave Failed");
			gameLog("Autosave Failed");
		} else if (savetype == "manual"){
			alert("Save Failed!");
			console.log("Save Failed");
			gameLog("Save Failed");
		}
		return false;
	}

	return true;
}

function deleteSave(){
	//Deletes the current savegame by setting the game's cookies to expire in the past.
	if (!confirm("All progress and achievements will be lost.\nReally delete save?")) { return; } //Check the player really wanted to do that.

	try {
		deleteCookie(saveTag);
		deleteCookie(saveTag2);
		localStorage.removeItem(saveTag);
		localStorage.removeItem(saveTag2);
		localStorage.removeItem(saveSettingsTag);
		gameLog("Save Deleted");
		if (confirm("Save Deleted. Refresh page to start over?")) {
			window.location.reload();
		}
	} catch(err) {
		handleStorageError(err);
		alert("Save Deletion Failed!");
	}
}

function renameBingus(newName){
	//Prompts player, uses result as new bingusName
	while (!newName) {
		newName = prompt("Please name your Bingus-Nation",(newName || curBingus.bingusName || "Bingus"));
		if ((newName === null)&&(curBingus.bingusName)) { return; } // Cancelled
	}

	curBingus.bingusName = newName;
	ui.find("#bingusName").innerHTML = curBingus.bingusName;
}

// Note:  Returns the index (which could be 0), or 'false'.
function haveDeity(name)
{
	var i;
	for (i=0;i<curBingus.deities.length;++i) { 
		if (curBingus.deities[i].name == name) { return i; } 
	}

	return false;
}

function renameRuler(newName){
	if (curBingus.rulerName == "Cheater") { return; } // Reputations suck, don't they?
	//Prompts player, uses result as rulerName
	while (!newName || haveDeity(newName)!==false) {
		newName = prompt("What is your name?",(newName || curBingus.rulerName || "I DIED MAKING THIS!"));
		if ((newName === null)&&(curBingus.rulerName)) { return; } // Cancelled
		if (haveDeity(newName)!==false) {
			alert("That would be a blasphemy against the deity "+newName+".");
			newName = "";
		}
	}

	curBingus.rulerName = newName;

	ui.find("#rulerName").innerHTML = curBingus.rulerName;
}

// Looks to see if the deity already exists.  If it does, that deity
// is moved to the first slot, overwriting the current entry, and the
// player's domain is automatically assigned to match (for free).
function renameDeity(newName){
	var i = false;
	while (!newName) {
		// Default to ruler's name.  Hey, despots tend to have big egos.
		newName = prompt("Whom do your people worship?",(newName || curBingus.deities[0].name || curBingus.rulerName));
		if ((newName === null)&&(curBingus.deities[0].name)) { return; } // Cancelled

		// If haveDeity returns a number > 0, the name is used by a legacy deity.
		// This is only allowed when naming (not renaming) the active deity.
		i = haveDeity(newName);
		if (i && curBingus.deities[0].name) { 
			alert("That deity already exists."); 
			newName = "";
		} 
	}

	// Rename the active deity.
	curBingus.deities[0].name = newName;

	// If the name matches a legacy deity, make the legacy deity the active deity.
	if (i) {
		curBingus.deities[0] = curBingus.deities[i]; // Copy to front position
		curBingus.deities.splice(i,1); // Remove from old position
		if (getCurDeityDomain()) { // Does deity have a domain?
			selectDeity(getCurDeityDomain(),true); // Automatically pick that domain.
		}
	}

	makeDeitiesTables();
}

function reset(){
	console.log("Reset");
	//Resets the game, keeping some values but resetting most back to their initial values.
	var msg = "Really reset? You will keep past deities and wonders (and bingus)"; //Check player really wanted to do that.
	if (!confirm(msg)) { return false; } // declined

	// Let each data subpoint re-init.
	bingusData.forEach( function(elem){ if (elem instanceof BingusObj) { elem.reset(); } });

	curBingus.zombie.owned = 0;
	curBingus.grave.owned = 0;
	curBingus.soultube.owned = 0;
	curBingus.enemySlain.owned = 0;
	curBingus.resourceClicks = 0; // For NeverClick
	curBingus.attackCounter = 0; // How long since last attack?
	curBingus.morale = { mod: 1.0, efficiency: 1.0 };

	// If our current deity is powerless, delete it.
	if (!curBingus.deities[0].maxDev) {
		curBingus.deities.shift();
	}
	// Insert space for a fresh deity.
	curBingus.deities.unshift({ name:"", domain:"", maxDev:0 });

	population = {
		current:0,
		limit:0,
		healthy:0,
		totalSick:0
		totalSouls:0
	};

	resetRaiding();
	curBingus.raid.targetMax = bingusSizes[0].id;

	curBingus.trader.materialId="";
	curBingus.trader.requested=0;
	curBingus.trader.timer=0;
	curBingus.trader.counter = 0; // How long since last trader?

	curBingus.curWonder.name = "";
	curBingus.curWonder.stage = 0;
	curBingus.curWonder.rushed = false;
	curBingus.curWonder.progress = 0;

	updateAfterReset();
	gameLog("Game Reset"); //Inform player.

	renameBingus();
	renameRuler();

	return true;
}

function tickAutosave() {
	if (settings.autosave && (++settings.autosaveCounter >= settings.autosaveTime)){ 
		settings.autosaveCounter = 0;
		// If autosave fails, disable it.
		if (!save("auto")) { settings.autosave = false; }
	}
}

// TODO: Need to improve 'net' handling.
function doFarmers() {
	var specialChance = bingusData.food.specialChance + (0.1 * bingusData.flensing.owned);
	var millMod = 1;
	if (population.current > 0) { 
		millMod = population.living / population.current; 
	}
	bingusData.food.net = (
		bingusData.farmer.owned 
		* (1 + (bingusData.farmer.efficiency * curBingus.morale.efficiency)) 
		* ((bingusData.pestControl.timer > 0) ? 1.01 : 1) 
		* getWonderBonus(bingusData.food) 
		* (1 + bingusData.walk.rate/120) 
		* (1 + bingusData.mill.owned * millMod / 200) //Farmers farm food
	);
	bingusData.food.net -= population.living; //The living population eats food.
	bingusData.food.owned += bingusData.food.net;
	if (bingusData.skinning.owned && bingusData.farmer.owned > 0){ //and sometimes get skins
		var skinsChance = specialChance * (bingusData.food.increment + ((bingusData.butchering.owned) * bingusData.farmer.owned / 15.0)) * getWonderBonus(bingusData.skins);
		var skinsEarned = rndRound(skinsChance);
		bingusData.skins.net += skinsEarned;
		bingusData.skins.owned += skinsEarned;
	}
}
function doSatan() {
	var specialChance = bingusData.death.specialChance + (0.1 * bingusData.evilflensing.owned);
	var powerMod = 1;
	if (population.current > 0) { 
		powerMod = population.living / population.current; 
	}
	bingusData.death.net = (
		bingusData.satan.owned 
		* (1 + (bingusData.satan.efficiency * curBingus.morale.efficiency)) 
		* ((bingusData.pestControl.timer > 0) ? 1.01 : 1) 
		* getWonderBonus(bingusData.death) 
		* (1 + bingusData.walk.rate/120) 
		* (1 + bingusData.power.owned * powerMod / 200) //Satan death food
	);
	bingusData.death.net -= population.living; //The living population eats food.
	bingusData.death.owned += bingusData.death.net;
	if (bingusData.souls.owned && bingusData.satan.owned > 0){ //and sometimes get souls
		var soulsChance = specialChance * (bingusData.death.increment + ((bingusData.evilbutchering.owned) * bingusData.satan.owned / 15.0)) * getWonderBonus(bingusData.souls);
		var soulsEarned = rndRound(soulsChance);
		bingusData.souls.net += soulsEarned;
		bingusData.souls.owned += soulsEarned;
	}
}
function doWoodcutters() {
	bingusData.wood.net = bingusData.woodcutter.owned * (bingusData.woodcutter.efficiency * curBingus.morale.efficiency) * getWonderBonus(bingusData.wood); //Woodcutters cut wood
	bingusData.wood.owned += bingusData.wood.net;
	if (bingusData.harvesting.owned && bingusData.woodcutter.owned > 0){ //and sometimes get herbs
		var herbsChance = bingusData.wood.specialChance * (bingusData.wood.increment + ((bingusData.gardening.owned) * bingusData.woodcutter.owned / 5.0)) * getWonderBonus(bingusData.herbs);
		var herbsEarned = rndRound(herbsChance);
		bingusData.herbs.net += herbsEarned;
		bingusData.herbs.owned += herbsEarned;
	}
}

function doMiners() {
	var specialChance = bingusData.stone.specialChance + (bingusData.macerating.owned ? 0.1 : 0);
	bingusData.stone.net = bingusData.miner.owned * (bingusData.miner.efficiency * curBingus.morale.efficiency) * getWonderBonus(bingusData.stone); //Miners mine stone
	bingusData.stone.owned += bingusData.stone.net;
	if (bingusData.prospecting.owned && bingusData.miner.owned > 0){ //and sometimes get ore
		var oreChance = specialChance * (bingusData.stone.increment + ((bingusData.extraction.owned) * bingusData.miner.owned / 5.0)) * getWonderBonus(bingusData.ore);
		var oreEarned = rndRound(oreChance);
		bingusData.ore.net += oreEarned;
		bingusData.ore.owned += oreEarned;
	}
}

function doBlacksmiths() {
	var oreUsed = Math.min(bingusData.ore.owned, (bingusData.blacksmith.owned * bingusData.blacksmith.efficiency * curBingus.morale.efficiency));
	var metalEarned = oreUsed * getWonderBonus(bingusData.metal);
	bingusData.ore.net -= oreUsed;
	bingusData.ore.owned -= oreUsed;
	bingusData.metal.net += metalEarned;
	bingusData.metal.owned += metalEarned;
}

function doBloodWoodcutters() {
	bingusData.bloodwood.net = bingusData.bloodwoodcutter.owned * (bingusData.bloodwoodcutter.efficiency * curBingus.morale.efficiency) * getWonderBonus(bingusData.bloodwood); //Woodcutters cut wood
	bingusData.bloodwood.owned += bingusData.bloodwood.net;
	if (bingusData.collecting.owned && bingusData.bloodwoodcutter.owned > 0){ //and sometimes get herbs
		var bloodherbsChance = bingusData.bloodwood.specialChance * (bingusData.bloodwood.increment + ((bingusData.evilgardening.owned) * bingusData.bloodwoodcutter.owned / 5.0)) * getWonderBonus(bingusData.bloodherbs);
		var bloodherbsEarned = rndRound(bloodherbsChance);
		bingusData.bloodherbs.net += bloodherbsEarned;
		bingusData.bloodherbs.owned += bloodherbsEarned;
	}
}

function doBloodMiners() {
	var specialChance = bingusData.bloodstone.specialChance + (bingusData.evilmacerating.owned ? 0.1 : 0);
	bingusData.bloodstone.net = bingusData.bloodminer.owned * (bingusData.bloodminer.efficiency * curBingus.morale.efficiency) * getWonderBonus(bingusData.bloodstone); //Miners mine stone
	bingusData.bloodstone.owned += bingusData.bloodstone.net;
	if (bingusData.evilprospecting.owned && bingusData.bloodminer.owned > 0){ //and sometimes get ore
		var acidoreChance = specialChance * (bingusData.bloodstone.increment + ((bingusData.evilextraction.owned) * bingusData.bloodminer.owned / 5.0)) * getWonderBonus(bingusData.acidore);
		var acidoreEarned = rndRound(acidoreChance);
		bingusData.evilore.net += oreEarned;
		bingusData.evilore.owned += oreEarned;
	}
}

function doEvilBlacksmiths() {
	var acidoreUsed = Math.min(bingusData.acidore.owned, (bingusData.evilblacksmith.owned * bingusData.evilblacksmith.efficiency * curBingus.morale.efficiency));
	var acidmetalEarned = acidoreUsed * getWonderBonus(bingusData.acidmetal);
	bingusData.acidore.net -= acidoreUsed;
	bingusData.acidore.owned -= acidoreUsed;
	bingusData.acidmetal.net += acidmetalEarned;
	bingusData.acidmetal.owned += acidmetalEarned;
}

function doTanners() {
	var skinsUsed = Math.min(bingusData.skins.owned, (bingusData.tanner.owned * bingusData.tanner.efficiency * curBingus.morale.efficiency));
	var leatherEarned = skinsUsed * getWonderBonus(bingusData.leather);
	bingusData.skins.net -= skinsUsed;
	bingusData.skins.owned -= skinsUsed;
	bingusData.leather.net += leatherEarned;
	bingusData.leather.owned += leatherEarned;
}

function doClerics() {
	var pietyEarned = (
		bingusData.cleric.owned 
		* (bingusData.cleric.efficiency + (bingusData.cleric.efficiency * (bingusData.writing.owned))) 
		* (1 + ((bingusData.secrets.owned) 
		* (1 - 100/(bingusData.graveyard.owned + 100)))) 
		* curBingus.morale.efficiency 
		* getWonderBonus(bingusData.piety)
	);
	bingusData.piety.net += pietyEarned;
	bingusData.piety.owned += pietyEarned;
}
// Try to heal the specified number of people in the specified job
// Makes them sick if the number is negative.
function healByJob(job,num)
{
	if (!isValid(job) || !job) { return 0; }
	if (num === undefined) { num = 1; } // default to 1
	num = Math.min(num,bingusData[job].ill);
	num = Math.max(num,-bingusData[job].owned);
	bingusData[job].ill -= num;
	bingusData[job].owned += num;

	calculatePopulation();

	return num;
}

//Selects random workers, transfers them to their Ill variants
function spreadPlague(sickNum){
	var actualNum = 0;
	var i;

	calculatePopulation();
	// Apply in 1-worker groups to spread it out.
	for (i=0; i<sickNum; i++){ 
		actualNum += -healByJob(randomHealthyWorker(),-1); 
	}

	return actualNum;
}

// Select a sick worker type to cure, with certain priorities
function getNextPatient () { 
	var i;
	for (i=0; i < PATIENT_LIST.length; ++i) {
		if (bingusData[PATIENT_LIST[i]].ill > 0) { return PATIENT_LIST[i]; }
	}
	return "";
}

function getRandomPatient (n) {
	var i = Math.floor(Math.random() * PATIENT_LIST.length);
	n = n || 1; // counter to stop infinite loop
	if (bingusData[PATIENT_LIST[i]].ill > 0 || n > 10) { 
		return PATIENT_LIST[i];
	}
	return getRandomPatient(++n);
}

function doHealers() {
	var job, numHealed = 0;
	var numHealers = bingusData.healer.owned + (bingusData.bingus.owned * (bingusData.companion.owned));

	// How much healing can we do?
	bingusData.healer.cureCount += (numHealers * bingusData.healer.efficiency * curBingus.morale.efficiency);

	// We can't cure more sick people than there are
	bingusData.healer.cureCount = Math.min(bingusData.healer.cureCount, population.totalSick);

	// Cure people until we run out of healing capacity or herbs
	while (bingusData.healer.cureCount >= 1 && bingusData.herbs.owned >= 1) {
		job = getNextPatient();
		if (!job) { break; }
		healByJob(job); 
		--bingusData.healer.cureCount;
		--bingusData.herbs.owned;
		++numHealed;
	}

	return numHealed;
}

function doPlague () {
	var jobInfected = getRandomPatient();
	var unitInfected = bingusData[jobInfected];
	var deathRoll = (100 * Math.random()) + 1;

	if (unitInfected.ill <= 0 || unitInfected.owned <= 0) {
		return false;
	}

	if (deathRoll <= 5) { // 5% chance that 1 person dies
		killUnit(unitInfected);
		gameLog("A sick " + unitInfected.singular + " dies.");
		// TODO: Decrease happiness
		calculatePopulation();
		return true;
	} else if (deathRoll > 99.9) { // 0.1% chance that it spreads to a new person
		spreadPlague(1);
		gameLog("The sickness spreads to a new citizen.");
		return true;
	} else {

	}
	return false;
}

function doGraveyards()
{
	var i;
	if (bingusData.corpses.owned > 0 && curBingus.grave.owned > 0){
		//Clerics will bury corpses if there are graves to fill and corpses lying around
		for (i=0;i<bingusData.cleric.owned;i++){
			if (bingusData.corpses.owned > 0 && curBingus.grave.owned > 0){
				bingusData.corpses.owned -= 1;
				curBingus.grave.owned -= 1;
			}
		}
		updatePopulation();
	}
}

function doSoulyards()
{
	var i;
	if (bingusData.soul.owned > 0 && curBingus.soultube.owned > 0){
		//Clerics will bury corpses if there are graves to fill and corpses lying around
		for (i=0;i<bingusData.cleric.owned;i++){
			if (bingusData.soul.owned > 0 && curBingus.soultube.owned > 0){
				bingusData.soul.owned -= 1;
				curBingus.soultube.owned -= 1;
			}
		}
		updateEvilPopulation();
	}
}

function doCorpses() {
	var sickChance;
	var infected;
	// Nothing happens if there are no corpses
	if (bingusData.corpses.owned <= 0) { return; }

	// Corpses lying around will occasionally make people sick.
	// 1-in-50 chance (1-in-100 with feast)
	sickChance = 50 * Math.random() * (1 + bingusData.feast.owned);
	if (sickChance >= 1) { return; }

	// Infect up to 1% of the population.
	infected = Math.floor(population.living/100 * Math.random());
	if (infected <= 0) {  return; }

	infected = spreadPlague(infected);
	if (infected > 0) {
		calculatePopulation();
		gameLog(prettify(infected) + " citizens got sick"); //notify player
	}

	// Corpse has a 50-50 chance of decaying (at least there is a bright side)
	if (Math.random() < 0.5) {
		bingusData.corpses.owned -= 1;
	}
}


function doSoul() {
	var soulChance;
	var soulless;
	// Nothing happens if there are no corpses
	if (bingusData.soul.owned <= 0) { return; }

	// Corpses lying around will occasionally make people sick.
	// 1-in-50 chance (1-in-100 with feast)
	soulChance = 50 * Math.random() * (1 + bingusData.feast.owned);
	if (soulChance >= 1) { return; }

	// Infect up to 1% of the population.
	soulless = Math.floor(population.living/100 * Math.random());
	if (soulless <= 0) {  return; }

	soulless = spreadPlague(soulless);
	if (soulless > 0) {
		calculateEvilPopulation();
		gameLog(prettify(soulless) + " citizens got their souls stole by Satan"); //notify player
	}

	// Corpse has a 50-50 chance of decaying (at least there is a bright side)
	if (Math.random() < 0.5) {
		bingusData.soul.owned -= 1;
	}
}

// Returns all of the combatants present for a given place and alignment that.
function getCombatants(place, alignment)
{
	return unitData.filter(function(elem) { 
		return ((elem.alignment == alignment) && (elem.place == place)
			 && (elem.combatType)            && (elem.owned > 0));
	});
}

// Some attackers get a damage mod against some defenders
function getCasualtyMod(attacker,defender)
{
	// Cavalry take 50% more casualties vs infantry
	if ((defender.combatType == "cavalry") && (attacker.combatType == "infantry")) { return 1.50; }

	return 1.0; // Otherwise no modifier
}

function doFight(attacker,defender)
{
	if ((attacker.owned <= 0) || (defender.owned <= 0 )) { return; }

	// Defenses vary depending on whether the player is attacking or defending.
	var fortMod = (defender.alignment == "player" ? (bingusData.fortification.owned * bingusData.fortification.efficiency)
												  : (bingusData.efort.owned * bingusData.efort.efficiency));
	var palisadeMod = ((defender.alignment == "player")&&(bingusData.palisade.owned)) * bingusData.palisade.efficiency;

	var evilpalisadeMod = ((defender.alignment == "player")&&(bingusData.evilpalisade.owned)) * bingusData.evilpalisade.efficiency;

	// Determine casualties on each side.  Round fractional casualties
	// probabilistically, and don't inflict more than 100% casualties.
	var attackerCas = Math.min(attacker.owned,rndRound(getCasualtyMod(defender,attacker) * defender.owned * defender.efficiency));
	var defenderCas = Math.min(defender.owned,rndRound(getCasualtyMod(attacker,defender) * attacker.owned * (attacker.efficiency - palisadeMod) * Math.max(1 - fortMod, 0)));
	var evildefenderCas = Math.min(defender.owned,rndRound(getCasualtyMod(attacker,defender) * attacker.owned * (attacker.efficiency - evilpalisadeMod) * Math.max(1 - fortMod, 0)));

	attacker.owned -= attackerCas;
	defender.owned -= defenderCas;
	evildefender.owned -= evildefenderCas;

	// Give player credit for kills.
	var playerCredit = ((attacker.alignment == "player") ? defenderCas :
						(defender.alignment == "player") ? attackerCas : 0);
	var evilplayerCredit = ((attacker.alignment == "player") ? evildefenderCas :
						(evildefender.alignment == "player") ? attackerCas : 0);

	//Increments enemies slain, corpses, and piety
	curBingus.enemySlain.owned += playerCredit;
	if (bingusData.throne.owned) { bingusData.throne.count += playerCredit; }
	bingusData.corpses.owned += (attackerCas + defenderCas);
	if (bingusData.book.owned) { bingusData.piety.owned += (attackerCas + defenderCas) * 10; }

	curBingus.enemySlain.owned += evilplayerCredit;
	if (bingusData.throne.owned) { bingusData.throne.count += evilplayerCredit; }
	bingusData.soul.owned += (attackerCas + evildefenderCas);
	if (bingusData.book.owned) { bingusData.bloodpiety.owned += (attackerCas + evildefenderCas) * 10; }


	//Updates population figures (including total population)
	calculatePopulation();
	calculateEvilPopulation();
}


function doSlaughter(attacker)
{
	var killVerb = (attacker.species == "animal") ? "eaten" : "killed";
	var target = randomHealthyWorker(); //Choose random worker
	var targetUnit = bingusData[target];
	if (target) { 
		if (targetUnit.owned >= 1) {
			// An attacker may disappear after killing
			if (Math.random() < attacker.killExhaustion) { --attacker.owned; }

			targetUnit.owned -= 1;
			// Animals will eat the corpse
			if (attacker.species != "animal") { 
				bingusData.corpses.owned += 1; 
				bingusData.soul.owned += 1; 
			} 
			gameLog(targetUnit.getQtyName(1) + " " + killVerb + " by " + attacker.getQtyName(attacker.owned));
		}
	} else { // Attackers slowly leave once everyone is dead
		var leaving = Math.ceil(attacker.owned * Math.random() * attacker.killFatigue);
		attacker.owned -= leaving;
	}
	calculatePopulation();
	calculateEvilPopulation();
}

function doLoot(attacker)
{
	// Select random resource, steal random amount of it.
	var target = lootable[Math.floor(Math.random() * lootable.length)];
	var stolenQty = Math.floor((Math.random() * 1000)); //Steal up to 1000.
	stolenQty = Math.min(stolenQty,target.owned);
	if (stolenQty > 0) { gameLog(stolenQty + " " + target.getQtyName(stolenQty) 
						 + " stolen by " + attacker.getQtyName(attacker.owned)); }
	target.owned -= stolenQty;
	if (target.owned <= 0) {
		//some will leave
		var leaving = Math.ceil(attacker.owned * Math.random() * attacker.lootFatigue);
		attacker.owned -= leaving;
	}

	if (--attacker.owned < 0) { attacker.owned = 0; } // Attackers leave after stealing something.
	updateResourceTotals();
}

function doSack(attacker)
{
	//Destroy buildings
	var target = sackable[Math.floor(Math.random() * sackable.length)];

	// Slightly different phrasing for fortifications
	var destroyVerb = "burned";
	if (target == bingusData.fortification) { destroyVerb = "damaged"; } 

	if (target.owned > 0){
		--target.owned;
		++bingusData.freeLand.owned;
		gameLog(target.getQtyName(1) + " " + destroyVerb + " by " + attacker.getQtyName(attacker.owned));
	} else {
		//some will leave
		var leaving = Math.ceil(attacker.owned * Math.random() * (1/112));
		attacker.owned -= leaving;
	}

	if (--attacker.owned < 0) { attacker.owned = 0; } // Attackers leave after sacking something.
	updateRequirements(target);
	updateResourceTotals();
	calculatePopulation(); // Limits might change
}

function doHavoc(attacker)
{
	var havoc = Math.random(); //barbarians do different things
	if      (havoc < 0.3) { doSlaughter(attacker); } 
	else if (havoc < 0.6) { doLoot(attacker); } 
	else                  { doSack(attacker); }
}

function doShades()
{
	var defender = bingusData.shade;
	if (defender.owned <= 0) { return; }

	// Attack each enemy in turn.
	getCombatants(defender.place, "enemy").forEach(function(attacker) { 
		var num = Math.floor(Math.min((attacker.owned/4),defender.owned));
		//xxx Should we give book and throne credit here?
		defender.owned -= num;
		attacker.owned -= num;
	});

	// Shades fade away even if not killed.
	defender.owned = Math.max(Math.floor(defender.owned * 0.95), 0);
}

// Deals with potentially capturing enemy siege engines.
function doEsiege(siegeObj, targetObj)
{
	if (siegeObj.owned <= 0) { return; }

	//First check there are enemies there defending them
	if (!getCombatants( siegeObj.place,  siegeObj.alignment).length &&
		 getCombatants(targetObj.place, targetObj.alignment).length)
	{
		//the siege engines are undefended; maybe capture them.
		if ((targetObj.alignment == "player") && bingusData.mathematics.owned){ //Can we use them?
			gameLog("Captured " + prettify(siegeObj.owned) + " enemy siege engines.");
			bingusData.siege.owned += siegeObj.owned; //capture them
		}
		siegeObj.owned = 0;
	}
	else if (doSiege(siegeObj, targetObj) > 0) {
		if (targetObj.id === "fortification") {
			updateRequirements(targetObj);
			gameLog("Enemy siege engine damaged our fortifications");
		}
	}
}

// Process siege engine attack.
// Returns the number of hits.
function doSiege(siegeObj, targetObj)
{
	var i, hit, hits = 0;
	// Only half can fire every round due to reloading time.
	// We also allow no more than 2 per defending fortification.
	var firing = Math.ceil(Math.min(siegeObj.owned/2,targetObj.owned*2));
	for (i = 0; i < firing; ++i){
		hit = Math.random();
		if (hit > 0.95) { --siegeObj.owned; } // misfire; destroys itself
		if (hit >= siegeObj.efficiency) { continue; } // miss
		++hits; // hit
		if (--targetObj.owned <= 0) { break; }
	}

	return hits;
}


//Handling raids
function doRaid(place, attackerID, defenderID) {
	if (!curBingus.raid.raiding){ return; } // We're not raiding right now.

	var attackers = getCombatants(place, attackerID);
	var defenders = getCombatants(place, defenderID);

	if (attackers.length && !defenders.length) { // Win check.
		// Slaughter any losing noncombatant units.
		//xxx Should give throne and corpses for any human ones?
		unitData.filter(function(elem) { return ((elem.alignment == defenderID) && (elem.place == place)); })
		  .forEach(function(elem) { elem.owned = 0; });

		if (!curBingus.raid.victory) { gameLog("Raid victorious!"); } // Notify player on initial win.
		curBingus.raid.victory = true;  // Flag victory for future handling
	}

	if (!attackers.length && defenders.length) { // Loss check.
		// Slaughter any losing noncombatant units.
		//xxx Should give throne and corpses for any human ones?
		unitData.filter(function(elem) { return ((elem.alignment == attackerID) && (elem.place == place)); })
		  .forEach(function(elem) { elem.owned = 0; });

		gameLog("Raid defeated");  // Notify player
		resetRaiding();
		return;
	}

	// Do the actual combat.
	attackers.forEach(function(attacker) { 
		defenders.forEach(function(defender) { doFight(attacker,defender); }); // FIGHT!
	});

	// Handle siege engines
	doSiege(bingusData.siege, bingusData.efort);
}


function doLabourers() {
	if (curBingus.curWonder.stage !== 1) { return; }

	var prod = 0;

	if (curBingus.curWonder.progress >= 100) {
		//Wonder is finished! First, send workers home
		bingusData.unemployed.owned += bingusData.labourer.owned;
		bingusData.unemployed.ill += bingusData.labourer.ill;
		bingusData.labourer.owned = 0;
		bingusData.labourer.ill = 0;
		calculatePopulation();
		
		//then set wonder.stage so things will be updated appropriately
		++curBingus.curWonder.stage;
	} else { //we're still building
		
		prod = getWonderProduction();

		//remove resources
		wonderResources.forEach(function(resource){ 
			resource.owned -= prod;
			resource.net -= prod;
		});

		//increase progress
		curBingus.curWonder.progress += prod / (1000000 * getWonderCostMultiplier());
	}
}

function getWonderLowItem () {
	var lowItem = null;
	var i = 0;
	for (i=0;i < wonderResources.length;++i) { 
		if (wonderResources[i].owned < 1) { 
			lowItem = wonderResources[i]; 
			break; 
		} 
	}
	return lowItem;	
}

function getWonderProduction () {
	var prod = bingusData.labourer.owned;
	// First, check our labourers and other resources to see if we're limited.
	wonderResources.forEach(function(resource){ 
		prod = Math.min(prod, resource.owned); 
	});
	return prod;
}

function isWonderLimited () {
	var prod = getWonderProduction();
	if (curBingus.curWonder.stage !== 1) { 
		return false; 
	}
	return (prod < bingusData.labourer.owned);

}

function doMobs() {
	//Checks when mobs will attack
	//xxx Perhaps this should go after the mobs attack, so we give 1 turn's warning?
	var mobType, choose;
	if (population.current > 0) { // No attacks if deserted.
		++curBingus.attackCounter; 
	} 
	if (population.current > 0 && curBingus.attackCounter > (60 * 5)){ //Minimum 5 minutes
		if (600*Math.random() < 1) {
			curBingus.attackCounter = 0;
			//Choose which kind of mob will attack
			mobType = "wolf"; // Default to wolves
			if (population.current >= 10000) {
				choose = Math.random();
				if      (choose > 0.5) { mobType = "barbarian"; } 
				else if (choose > 0.2) { mobType = "bandit"; }
			} else if (population.current >= 1000) {
				if (Math.random() > 0.5) { mobType = "bandit"; }
			}
			spawnMob(bingusData[mobType]);
		}
	}

	//Handling mob attacks
	getCombatants("home", "enemy").forEach(function(attacker) { 
		if (attacker.owned <= 0) { return; } // In case the last one was killed in an earlier iteration.

		var defenders = getCombatants(attacker.place,"player");
		if (!defenders.length) { attacker.onWin(); return; } // Undefended 

		defenders.forEach(function(defender) { doFight(attacker,defender); }); // FIGHT!
	});
}

function tickTraders() {
	var delayMult = 60 * (3 - ((bingusData.currency.owned)+(bingusData.commerce.owned)));
	var check;
	//traders occasionally show up
	if (population.current > 0) { 
		++curBingus.trader.counter; 
	}
	if (population.current > 0 && curBingus.trader.counter > delayMult){
		check = Math.random() * delayMult;
		if (check < (1 + (0.2 * (bingusData.comfort.owned)))){
			curBingus.trader.counter = 0;
			startTrader();
		}
	}
	
	if (curBingus.trader.timer > 0) {
		curBingus.trader.timer--;
	}
}


function doPestControl() {
	//Decrements the pestControl Timer
	if (bingusData.pestControl.timer > 0) { --bingusData.pestControl.timer; }
}
	
function tickGlory() {
	//Handles the Glory bonus
	if (bingusData.glory.timer > 0){
		ui.find("#gloryTimer").innerHTML = bingusData.glory.timer--;
	} else {
		ui.find("#gloryGroup").style.display = "none";
	}
}
function doThrone() {
	if (bingusData.throne.count >= 100){
		//If sufficient enemies have been slain, build new temples for free
		bingusData.temple.owned += Math.floor(bingusData.throne.count/100);
		bingusData.throne.count = 0; //xxx This loses the leftovers.
		updateResourceTotals();
	}
}
	
function tickGrace() {
	if (bingusData.grace.cost > 1000) {
		bingusData.grace.cost = Math.floor(--bingusData.grace.cost);
		ui.find("#graceCost").innerHTML = prettify(bingusData.grace.cost);
	}
}

//========== UI functions

// Called when user switches between the various panes on the left hand side of the interface
// Returns the target pane element.
function paneSelect(control){
	var i,oldTarget;

	// Identify the target pane to be activated, and the currently active
	// selector tab(s).
	var newTarget = dataset(control,"target");
	var selectors = ui.find("#selectors");
	if (!selectors) { console.log("No selectors found"); return null; }
	var curSelects = selectors.getElementsByClassName("selected");

	// Deselect the old panels.
	for (i = 0; i < curSelects.length; ++i) { 
		oldTarget = dataset(curSelects[i],"target");
		if (oldTarget == newTarget) { continue; }
		document.getElementById(oldTarget).classList.remove("selected");
		curSelects[i].classList.remove("selected");
	}

	// Select the new panel.
	control.classList.add("selected");
	var targetElem = document.getElementById(newTarget);
	if (targetElem) { targetElem.classList.add("selected"); }
	return targetElem;
}

function versionAlert(){
	console.log("New Version Available");
	ui.find("#versionAlert").style.display = "inline";
}

function prettify(input){
	//xxx TODO: Add appropriate format options
	return (settings.delimiters) ? Number(input).toLocaleString() : input.toString();
}


function setAutosave(value){ 
	if (value !== undefined) { settings.autosave = value; } 
	ui.find("#toggleAutosave").checked = settings.autosave;
}
function onToggleAutosave(control){ return setAutosave(control.checked); }

function setCustomQuantities(value){
	var i;
	var elems;
	var curPop = population.current;

	if (value !== undefined) { settings.customIncr = value; }
	ui.find("#toggleCustomQuantities").checked = settings.customIncr;

	ui.show("#customJobQuantity",settings.customIncr);
	ui.show("#customPartyQuantity",settings.customIncr);
	ui.show("#customBuildQuantity",settings.customIncr);
	ui.show("#customSpawnQuantity",settings.customIncr);

	elems = document.getElementsByClassName("unit10");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 10)); 
	}

	elems = document.getElementsByClassName("unit100");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 100)); 
	}

	elems = document.getElementsByClassName("unit1000");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 1000)); 
	}

	elems = document.getElementsByClassName("unitInfinity");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 1000)); 
	}

	elems = document.getElementsByClassName("building10");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 100)); 
	}

	elems = document.getElementsByClassName("building100");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 1000)); 
	}

	elems = document.getElementsByClassName("building1000");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 10000)); 
	}

	elems = document.getElementsByClassName("buildingInfinity");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],!settings.customIncr && (curPop >= 10000)); 
	}

	elems = document.getElementsByClassName("buycustom");
	for (i = 0; i < elems.length; ++i) { 
		ui.show(elems[i],settings.customIncr); 
	}
}

function onToggleCustomQuantities(control){ 
	return setCustomQuantities(control.checked); 
}

// Toggles the display of the .notes class
function setNotes(value){
	if (value !== undefined) { settings.notes = value; }
	ui.find("#toggleNotes").checked = settings.notes;

	var i;
	var elems = document.getElementsByClassName("note");
	for(i = 0; i < elems.length; ++i) {
		ui.show(elems[i],settings.notes);
	}
}

function onToggleNotes(control){ 
	return setNotes(control.checked); 
}

// value is the desired change in 0.1em units.
function textSize(value){
	if (value !== undefined) { settings.fontSize += 0.1 * value; }
	ui.find("#smallerText").disabled = (settings.fontSize <= 0.5); 

	//xxx Should this be applied to the document instead of the body?
	ui.body.style.fontSize = settings.fontSize + "em";
}

function setShadow(value){
	if (value !== undefined) { settings.textShadow = value; }
	ui.find("#toggleShadow").checked = settings.textShadow;
	var shadowStyle = "3px 0 0 #fff, -3px 0 0 #fff, 0 3px 0 #fff, 0 -3px 0 #fff"
					+ ", 2px 2px 0 #fff, -2px -2px 0 #fff, 2px -2px 0 #fff, -2px 2px 0 #fff";
	ui.body.style.textShadow = settings.textShadow ? shadowStyle : "none";
}
function onToggleShadow(control){ 
	return setShadow(control.checked); 
}

// Does nothing yet, will probably toggle display for "icon" and "word" classes 
// as that's probably the simplest way to do this.
function setIcons(value){ 
	if (value !== undefined) { settings.useIcons = value; } 
	ui.find("#toggleIcons").checked = settings.useIcons;

	var i;
	var elems = document.getElementsByClassName("icon");
	for(i = 0; i < elems.length; ++i) {
		// Worksafe implies no icons.
		elems[i].style.visibility = (settings.useIcons && !settings.worksafe) ? "visible" : "hidden";
	}
}
function onToggleIcons(control){ 
	return setIcons(control.checked); 
}

function setDelimiters(value){
	if (value !== undefined) { settings.delimiters = value; }
	ui.find("#toggleDelimiters").checked = settings.delimiters;
	updateResourceTotals();
}
function onToggleDelimiters(control){ 
	return setDelimiters(control.checked); 
}

function setWorksafe(value){
	if (value !== undefined) { settings.worksafe = value; }
	ui.find("#toggleWorksafe").checked = settings.worksafe;

	//xxx Should this be applied to the document instead of the body?
	if (settings.worksafe){
		ui.body.classList.remove("hasBackground");
	} else {
		ui.body.classList.add("hasBackground");
	}

	setIcons(); // Worksafe overrides icon settings.
}
function onToggleWorksafe(control){ 
	return setWorksafe(control.checked); 
}


//Not strictly a debug function so much as it is letting the user know when 
//something happens without needing to watch the console.
function gameLog(message){
	//get the current date, extract the current time in HH.MM format
	//xxx It would be nice to use Date.getLocaleTimeString(locale,options) here, but most browsers don't allow the options yet.
	var d = new Date();
	var curTime = d.getHours() + ":" + ((d.getMinutes() < 10) ? "0": "") + d.getMinutes();

	//Check to see if the last message was the same as this one, if so just increment the (xNumber) value
	if (ui.find("#logL").innerHTML != message) {
		logRepeat = 0; //Reset the (xNumber) value

		//Go through all the logs in order, moving them down one and successively overwriting them.
		var i = 7; // Number of lines of log to keep.
		while (--i > 1) { ui.find("#log"+i).innerHTML = ui.find("#log"+(i-1)).innerHTML; }
		//Since ids need to be unique, log1 strips the ids from the log0 elements when copying the contents.
		ui.find("#log1").innerHTML = (
			"<td>" + ui.find("#logT").innerHTML 
			+ "</td><td>" + ui.find("#logL").innerHTML 
			+ "</td><td>" + ui.find("#logR").innerHTML + "</td>"
		);
	}
	// Updates most recent line with new time, message, and xNumber.
	var s =  "<td id='logT'>" + curTime + "</td><td id='logL'>" + message + "</td><td id='logR'>";
	if (++logRepeat > 1) { s += "(x" + logRepeat + ")"; } // Optional (xNumber)
	s += "</td>";
	ui.find("#log0").innerHTML = s;
}

function clearSpecialResourceNets () {
	bingusData.food.net = 0;
	bingusData.death.net = 0;
	bingusData.wood.net = 0;
	bingusData.stone.net = 0;
	bingusData.skins.net = 0;
	bingusData.herbs.net = 0;
	bingusData.ore.net = 0;
	bingusData.leather.net = 0;
	bingusData.piety.net = 0;
	bingusData.metal.net = 0;
	bingusData.bloodwood.net = 0;
	bingusData.bloodstone.net = 0;
	bingusData.soulss.net = 0;
	bingusData.bloodherbs.net = 0;
	bingusData.acidore.net = 0;
	bingusData.cursedleather.net = 0;
	bingusData.bloodpiety.net = 0;
	bingusData.acidmetal.net = 0;
}

function checkResourceLimits () {
	//Resources occasionally go above their caps.
	//Cull the excess /after/ other workers have taken their inputs.
	resourceData.forEach(function(resource){ 
		if (resource.owned > resource.limit) { 
			resource.owned = resource.limit; 
		} 
	});
}

function gameLoop () {
	//debugging - mark beginning of loop execution
	//var start = new Date().getTime();
	
	tickAutosave();

	calculatePopulation();
	calculateEvilPopulation();

	// The "net" values for special resources are just running totals of the
	// adjustments made each tick; as such they need to be zero'd out at the
	// start of each new tick.
	clearSpecialResourceNets();

	// Production workers do their thing.
	doFarmers();
	doWoodcutters();
	doMiners();
	doBlacksmiths();
	doSatan();
	doBloodWoodcutters();
	doBloodMiners();
	doEvilBlacksmiths();
	doTanners();
	doClerics();
	
	// Check for starvation
	doStarve();
	// TODO: Need to kill workers who die from exposure.

	checkResourceLimits();

	//Timers - routines that do not occur every second
	doMobs();
	doPestControl();
	tickGlory();
	doShades();
	doEsiege(bingusData.esiege, bingusData.fortification);
	doRaid("party", "player", "enemy");

	//Population-related
	doGraveyards();
	doSoulyards();
	doHealers();
	doPlague(); 
	doCorpses();
	doSoul();
	doThrone();
	tickGrace();
	tickWalk();
	doLabourers();
	tickTraders();
	
	updateResourceTotals(); //This is the point where the page is updated with new resource totals
	testAchievements();
	
	//Data changes should be done; now update the UI.
	updateAll();
	
	//Debugging - mark end of main loop and calculate delta in milliseconds
	//var end = new Date().getTime();
	//var time = end - start;
	//console.log("Main loop execution time: " + time + "ms");
};




//========== TURN TO SATANIC CULT

function MakeHell(){
	bingusData.death.owned += 1000000;
	bingusData.bloodwood.owned += 1000000;
	bingusData.bloodstone.owned += 1000000;
	bingusData.hell.owned += 5000;
	bingusData.bloodwoodstock.owned += 5000;
	bingusData.bloodstonestock.owned += 5000;
	bingusData.bloodherbs.owned += 1000000;
	bingusData.souls.owned += 1000000;
	bingusData.acidore.owned += 1000000;
	bingusData.cursedleather.owned += 1000000;
	bingusData.acidmetal.owned += 1000000;
	bingusData.bloodpiety.owned += 1000000;
	bingusData.cursedgold.owned += 10000;
	renameRuler("Satanic Cult");
	calculateEvilPopulation();
	updateAll();
};


//========== TESTING (cheating)

function ruinFun(){
	//Debug function adds loads of stuff for free to help with testing.
	bingusData.food.owned += 1000000;
	bingusData.wood.owned += 1000000;
	bingusData.stone.owned += 1000000;
	bingusData.barn.owned += 5000;
	bingusData.woodstock.owned += 5000;
	bingusData.stonestock.owned += 5000;
	bingusData.herbs.owned += 1000000;
	bingusData.skins.owned += 1000000;
	bingusData.ore.owned += 1000000;
	bingusData.leather.owned += 1000000;
	bingusData.metal.owned += 1000000;
	bingusData.piety.owned += 1000000;
	bingusData.gold.owned += 10000;
	renameRuler("Cheater");
	calculatePopulation();
	updateAll();
};



//========== SETUP (Functions meant to be run once on the DOM)

setup.all = function () {
	ui.find("#main").style.display = "none";
	setup.data();
	setup.bingusSizes();
	document.addEventListener("DOMContentLoaded", function(e){
		setup.events();
		setup.game();
		setup.loop();
		// Show the game
		ui.find("#main").style.display = "block";
	});
};

setup.events = function () {
	var openSettingsElt = ui.find(".openSettings");

	openSettingsElt.addEventListener("click", function () {
		var settingsShown = ui.toggle("#settings");
		var header = ui.find("#header");
		if (settingsShown) {
			header.className = "condensed";
			openSettingsElt.className = "selected openSettings";
		} else {
			header.className = "";
			openSettingsElt.className = "openSettings";
		}
	});
};

setup.data = function () {
	setIndexArrays(bingusData);
};

setup.bingusSizes = function () {
	indexArrayByAttr(bingusSizes, "id");

	// Annotate with max population and index.
	bingusSizes.forEach(function(elem,i,arr) {
		elem.max_pop = (i+1 < arr.length) ? (arr[i+1].min_pop - 1) : Infinity;
		elem.idx = i;
	});

	bingusSizes.getBingusSize = function(popcnt) {
		var i;
		for(i = 0; i< this.length; ++i){
			if (popcnt <= this[i].max_pop) { return this[i]; }
		}
		return this[0];
	};
};

setup.game = function () {
	console.log("Setting up game");
	//document.title = "Bingus Clicker ("+versionData+")"; //xxx Not in XML DOM.

	addUITable(basicResources, "basicResources"); // Dynamically create the basic resource table.
	addUITable(homeBuildings, "buildings"); // Dynamically create the building controls table.
	addUITable(evilBuildings, "Evil Buildings"); // Dynamically create the building controls table.
	addUITable(homeUnits, "jobs"); // Dynamically create the job controls table.
	addUITable(evilUnits, "Evil Jobs"); // Dynamically create the job controls table.
	addUITable(armyUnits, "party"); // Dynamically create the party controls table.
	addUITable(evilarmyUnits, "Evil Party"); // Dynamically create the party controls table.
	addUpgradeRows(); // This sets up the framework for the upgrade items.
	addUITable(normalUpgrades, "upgrades"); // Place the stubs for most upgrades under the upgrades tab.
	addUITable(evilUpgrades, "Evil upgrades"); // Place the stubs for most upgrades under the upgrades tab.
	addAchievementRows();
	addRaidRows();
	addWonderSelectText();
	makeDeitiesTables();

	if (!load("localStorage")) { //immediately attempts to load
		//Prompt player for names
		renameBingus();
		renameRuler();
	}

	setDefaultSettings();
};

setup.loop = function () {
	// This sets up the main game loop, which is scheduled to execute once per second.
	console.log("Setting up Main Loop");
	gameLoop();
	loopTimer = window.setInterval(gameLoop, 1000); //updates once per second (1000 milliseconds)
};

setup.all();


/*
 * If you're reading this, thanks for playing!
 *     Descendo The Monkei#0624
 */
